Configuration minimale : un mac équipé de Yosemite



1) Dans le menu "Aller/Aller au dossier" du finder, ouvrir le dossier racine des sites web locaux :

/Library/WebServer/Documents/

et y placer le dossier dgpad de l'archive (le mot de passe administrateur est demandé).

2) Pour activer le php, procéder comme suit :
		a) Taper dans le terminal : sudo nano /etc/apache2/httpd.conf
		b) Utiliser "ctrl w" pour chercher une occurence du mot "php". 
		Cela devrait vous amener à la ligne "#LoadModule php5_module libexec/apache2/libphp5.so".
		c) Décommenter cette ligne en enlevant le caractère "#"
		d) enregistrer et quitter ("ctrl o" et ensuite "ctrl x")

3) Lancer le serveur Apache : sudo apachectl start

4) Dans le navigateur du mac, taper comme adresse :
		
		http://localhost/dgpad/conference/
		
Vous arrivez sur une page web modèle avec un lien vers une figure DGPad.

Le dossier conference est dans le dossier /Library/WebServer/Documents/dgpad/conference de
votre mac. En observant le lien, et le contenu du dossier "conference", vous comprendrez la suite !

NB : Depuis une tablette situé sur le même réseau que le mac, il ne faut pas utiliser localhost pour l'adresse de la page, mais plutôt l'adresse IP de ce mac.

Par exemple, si votre IP sur le réseau local est 192.168.1.99 (voir dans préférences->réseau) : 

		http://192.168.1.99/dgpad/conference/


Dernière remarque : Cette technique permet aussi d'animer un atelier en 100% local, avec plusieurs tablettes qui se connectent à votre réseau wifi (réseau que l'on peut créer avec par exemple un partage de connexion sur un smartphone).