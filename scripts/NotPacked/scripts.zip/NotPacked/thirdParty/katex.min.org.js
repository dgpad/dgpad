(function (e) {
    if ("function" == typeof bootstrap)
        bootstrap("katex", e);
    else if ("object" == typeof exports)
        module.exports = e();
    else if ("function" == typeof define && define.amd)
        define(e);
    else if ("undefined" != typeof ses) {
        if (!ses.ok())
            return;
        ses.makeKatex = e
    } else
        "undefined" != typeof window ? window.katex = e() : global.katex = e()
})(function () {
    var e, t, i, h, a;
    return function l(e, t, i) {
        function h(s, r) {
            if (!t[s]) {
                if (!e[s]) {
                    var p = typeof require == "function" && require;
                    if (!r && p)
                        return p(s, !0);
                    if (a)
                        return a(s, !0);
                    throw new Error("Cannot find module '" + s + "'")
                }
                var c = t[s] = {exports: {}};
                e[s][0].call(c.exports, function (t) {
                    var i = e[s][1][t];
                    return h(i ? i : t)
                }, c, c.exports, l, e, t, i)
            }
            return t[s].exports
        }
        var a = typeof require == "function" && require;
        for (var s = 0; s < i.length; s++)
            h(i[s]);
        return h
    }({1: [function (e, t, i) {
                var h = e("./src/ParseError");
                var a = e("./src/buildTree");
                var l = e("./src/parseTree");
                var s = e("./src/utils");
                var r = function (e, t) {
                    s.clearNode(t);
                    var i = l(e);
                    var h = a(i).toNode();
                    t.appendChild(h)
                };
                if (typeof document !== "undefined") {
                    if (document.compatMode !== "CSS1Compat") {
                        typeof console !== "undefined" && console.warn("Warning: KaTeX doesn't work in quirks mode. Make sure your " + "website has a suitable doctype.");
                        r = function () {
                            throw new h("KaTeX doesn't work in quirks mode.")
                        }
                    }
                }
                var p = function (e) {
                    var t = l(e);
                    return a(t).toMarkup()
                };
                t.exports = {render: r, renderToString: p, ParseError: h}
            }, {"./src/ParseError": 4, "./src/buildTree": 8, "./src/parseTree": 13, "./src/utils": 15}], 2: [function (e, t, i) {
                var h = e("./ParseError");
                function a(e) {
                    this._input = e
                }
                function l(e, t, i) {
                    this.text = e;
                    this.data = t;
                    this.position = i
                }
                var s = [/^[/|@.""`0-9a-zA-Z]/, /^[*+-]/, /^[=<>:]/, /^[,;]/, /^['\^_{}]/, /^[(\[]/, /^[)\]?!]/, /^~/];
                var r = [/^[a-zA-Z0-9`!@*()-=+\[\]'";:?\/.,]/, /^[{}]/, /^~/];
                var p = /^\s*/;
                var c = /^( +|\\  +)/;
                var g = /^\\(?:[a-zA-Z]+|.)/;
                a.prototype._innerLex = function (e, t, i) {
                    var a = this._input.slice(e);
                    var s;
                    if (i) {
                        s = a.match(p)[0];
                        e += s.length;
                        a = a.slice(s.length)
                    } else {
                        s = a.match(c);
                        if (s !== null) {
                            return new l(" ", null, e + s[0].length)
                        }
                    }
                    if (a.length === 0) {
                        return new l("EOF", null, e)
                    }
                    var r;
                    if (r = a.match(g)) {
                        return new l(r[0], null, e + r[0].length)
                    } else {
                        for (var d = 0; d < t.length; d++) {
                            var n = t[d];
                            if (r = a.match(n)) {
                                return new l(r[0], null, e + r[0].length)
                            }
                        }
                    }
                    throw new h("Unexpected character: '" + a[0] + "'", this, e)
                };
                var d = /^(#[a-z0-9]+|[a-z]+)/i;
                a.prototype._innerLexColor = function (e) {
                    var t = this._input.slice(e);
                    var i = t.match(p)[0];
                    e += i.length;
                    t = t.slice(i.length);
                    var a;
                    if (a = t.match(d)) {
                        return new l(a[0], null, e + a[0].length)
                    } else {
                        throw new h("Invalid color", this, e)
                    }
                };
                var n = /^(-?)\s*(\d+(?:\.\d*)?|\.\d+)\s*([a-z]{2})/;
                a.prototype._innerLexSize = function (e) {
                    var t = this._input.slice(e);
                    var i = t.match(p)[0];
                    e += i.length;
                    t = t.slice(i.length);
                    var a;
                    if (a = t.match(n)) {
                        var s = a[3];
                        if (s !== "em" && s !== "ex") {
                            throw new h("Invalid unit: '" + s + "'", this, e)
                        }
                        return new l(a[0], {number: +(a[1] + a[2]), unit: s}, e + a[0].length)
                    }
                    throw new h("Invalid size", this, e)
                };
                a.prototype._innerLexWhitespace = function (e) {
                    var t = this._input.slice(e);
                    var i = t.match(p)[0];
                    e += i.length;
                    return new l(i, null, e)
                };
                a.prototype.lex = function (e, t) {
                    if (t === "math") {
                        return this._innerLex(e, s, true)
                    } else if (t === "text") {
                        return this._innerLex(e, r, false)
                    } else if (t === "color") {
                        return this._innerLexColor(e)
                    } else if (t === "size") {
                        return this._innerLexSize(e)
                    } else if (t === "whitespace") {
                        return this._innerLexWhitespace(e)
                    }
                };
                t.exports = a
            }, {"./ParseError": 4}], 3: [function (e, t, i) {
                function h(e, t, i, h, a) {
                    this.style = e;
                    this.color = i;
                    this.size = t;
                    if (h === undefined) {
                        h = e
                    }
                    this.parentStyle = h;
                    if (a === undefined) {
                        a = t
                    }
                    this.parentSize = a
                }
                h.prototype.withStyle = function (e) {
                    return new h(e, this.size, this.color, this.style, this.size)
                };
                h.prototype.withSize = function (e) {
                    return new h(this.style, e, this.color, this.style, this.size)
                };
                h.prototype.withColor = function (e) {
                    return new h(this.style, this.size, e, this.style, this.size)
                };
                h.prototype.reset = function () {
                    return new h(this.style, this.size, this.color, this.style, this.size)
                };
                var a = {"katex-blue": "#6495ed", "katex-orange": "#ffa500", "katex-pink": "#ff00af", "katex-red": "#df0030", "katex-green": "#28ae7b", "katex-gray": "gray", "katex-purple": "#9d38bd"};
                h.prototype.getColor = function () {
                    return a[this.color] || this.color
                };
                t.exports = h
            }, {}], 4: [function (e, t, i) {
                function h(e, t, i) {
                    var a = "KaTeX parse error: " + e;
                    if (t !== undefined && i !== undefined) {
                        a += " at position " + i + ": ";
                        var l = t._input;
                        l = l.slice(0, i) + "\u0332" + l.slice(i);
                        var s = Math.max(0, i - 15);
                        var r = i + 15;
                        a += l.slice(s, r)
                    }
                    var p = new Error(a);
                    p.name = "ParseError";
                    p.__proto__ = h.prototype;
                    p.position = i;
                    return p
                }
                h.prototype.__proto__ = Error.prototype;
                t.exports = h
            }, {}], 5: [function (e, t, i) {
                var h = e("./functions");
                var a = e("./Lexer");
                var l = e("./symbols");
                var s = e("./utils");
                var r = e("./ParseError");
                function p(e) {
                    this.lexer = new a(e)
                }
                function c(e, t, i) {
                    this.type = e;
                    this.value = t;
                    this.mode = i
                }
                function g(e, t) {
                    this.result = e;
                    this.position = t
                }
                function d(e, t, i, h, a, l) {
                    this.result = e;
                    this.isFunction = t;
                    this.allowedInText = i;
                    this.numArgs = h;
                    this.numOptionalArgs = a;
                    this.argTypes = l
                }
                p.prototype.expect = function (e, t) {
                    if (e.text !== t) {
                        throw new r("Expected '" + t + "', got '" + e.text + "'", this.lexer, e.position)
                    }
                };
                p.prototype.parse = function (e) {
                    var t = this.parseInput(0, "math");
                    return t.result
                };
                p.prototype.parseInput = function (e, t) {
                    var i = this.parseExpression(e, t, false, null);
                    var h = this.lexer.lex(i.position, t);
                    this.expect(h, "EOF");
                    return i
                };
                p.prototype.parseExpression = function (e, t, i, h) {
                    var a = [];
                    while (true) {
                        var l = this.lexer.lex(e, t);
                        if (h != null && l.text === h) {
                            break
                        }
                        var s = this.parseAtom(e, t);
                        if (!s) {
                            break
                        }
                        if (i && s.result.type === "infix") {
                            break
                        }
                        a.push(s.result);
                        e = s.position
                    }
                    return new g(this.handleInfixNodes(a, t), e)
                };
                p.prototype.handleInfixNodes = function (e, t) {
                    var i = -1;
                    var a;
                    var l;
                    for (var s = 0; s < e.length; s++) {
                        var p = e[s];
                        if (p.type === "infix") {
                            if (i !== -1) {
                                throw new r("only one infix operator per group", this.lexer, -1)
                            }
                            i = s;
                            l = p.value.replaceWith;
                            a = h.funcs[l]
                        }
                    }
                    if (i !== -1) {
                        var g, d;
                        var n = e.slice(0, i);
                        var o = e.slice(i + 1);
                        if (n.length === 1 && n[0].type === "ordgroup") {
                            g = n[0]
                        } else {
                            g = new c("ordgroup", n, t)
                        }
                        if (o.length === 1 && o[0].type === "ordgroup") {
                            d = o[0]
                        } else {
                            d = new c("ordgroup", o, t)
                        }
                        var w = a.handler(l, g, d);
                        return[new c(w.type, w, t)]
                    } else {
                        return e
                    }
                };
                var n = 1;
                p.prototype.handleSupSubscript = function (e, t, i, a) {
                    var l = this.parseGroup(e, t);
                    if (!l) {
                        throw new r("Expected group after '" + i + "'", this.lexer, e)
                    } else if (l.numArgs > 0) {
                        var s = h.getGreediness(l.result.result);
                        if (s > n) {
                            return this.parseFunction(e, t)
                        } else {
                            throw new r("Got function '" + l.result.result + "' with no arguments " + "as " + a, this.lexer, e)
                        }
                    } else {
                        return l.result
                    }
                };
                p.prototype.parseAtom = function (e, t) {
                    var i = this.parseImplicitGroup(e, t);
                    if (t === "text") {
                        return i
                    }
                    var h;
                    if (!i) {
                        h = e;
                        i = undefined
                    } else {
                        h = i.position
                    }
                    var a;
                    var l;
                    var s;
                    while (true) {
                        var p = this.lexer.lex(h, t);
                        if (p.text === "^") {
                            if (a) {
                                throw new r("Double superscript", this.lexer, h)
                            }
                            s = this.handleSupSubscript(p.position, t, p.text, "superscript");
                            h = s.position;
                            a = s.result
                        } else if (p.text === "_") {
                            if (l) {
                                throw new r("Double subscript", this.lexer, h)
                            }
                            s = this.handleSupSubscript(p.position, t, p.text, "subscript");
                            h = s.position;
                            l = s.result
                        } else if (p.text === "'") {
                            var d = new c("textord", "\\prime", t);
                            var n = [d];
                            h = p.position;
                            while ((p = this.lexer.lex(h, t)).text === "'") {
                                n.push(d);
                                h = p.position
                            }
                            a = new c("ordgroup", n, t)
                        } else {
                            break
                        }
                    }
                    if (a || l) {
                        return new g(new c("supsub", {base: i && i.result, sup: a, sub: l}, t), h)
                    } else {
                        return i
                    }
                };
                var o = ["\\tiny", "\\scriptsize", "\\footnotesize", "\\small", "\\normalsize", "\\large", "\\Large", "\\LARGE", "\\huge", "\\Huge"];
                var w = ["\\displaystyle", "\\textstyle", "\\scriptstyle", "\\scriptscriptstyle"];
                p.prototype.parseImplicitGroup = function (e, t) {
                    var i = this.parseSymbol(e, t);
                    if (!i || !i.result) {
                        return this.parseFunction(e, t)
                    }
                    var h = i.result.result;
                    var a;
                    if (h === "\\left") {
                        var l = this.parseFunction(e, t);
                        a = this.parseExpression(l.position, t, false, "}");
                        var p = this.parseSymbol(a.position, t);
                        if (p && p.result.result === "\\right") {
                            var d = this.parseFunction(a.position, t);
                            return new g(new c("leftright", {body: a.result, left: l.result.value.value, right: d.result.value.value}, t), d.position)
                        } else {
                            throw new r("Missing \\right", this.lexer, a.position)
                        }
                    } else if (h === "\\right") {
                        return null
                    } else if (s.contains(o, h)) {
                        a = this.parseExpression(i.result.position, t, false, "}");
                        return new g(new c("sizing", {size: "size" + (s.indexOf(o, h) + 1), value: a.result}, t), a.position)
                    } else if (s.contains(w, h)) {
                        a = this.parseExpression(i.result.position, t, true, "}");
                        return new g(new c("styling", {style: h.slice(1, h.length - 5), value: a.result}, t), a.position)
                    } else {
                        return this.parseFunction(e, t)
                    }
                };
                p.prototype.parseFunction = function (e, t) {
                    var i = this.parseGroup(e, t);
                    if (i) {
                        if (i.isFunction) {
                            var a = i.result.result;
                            if (t === "text" && !i.allowedInText) {
                                throw new r("Can't use function '" + a + "' in text mode", this.lexer, i.position)
                            }
                            var l = i.result.position;
                            var s;
                            var p = i.numArgs + i.numOptionalArgs;
                            if (p > 0) {
                                var d = h.getGreediness(a);
                                var n = [a];
                                var o = [l];
                                for (var w = 0; w < p; w++) {
                                    var k = i.argTypes && i.argTypes[w];
                                    var u;
                                    if (w < i.numOptionalArgs) {
                                        if (k) {
                                            u = this.parseSpecialGroup(l, k, t, true)
                                        } else {
                                            u = this.parseOptionalGroup(l, t)
                                        }
                                        if (!u) {
                                            n.push(null);
                                            o.push(l);
                                            continue
                                        }
                                    } else {
                                        if (k) {
                                            u = this.parseSpecialGroup(l, k, t)
                                        } else {
                                            u = this.parseGroup(l, t)
                                        }
                                        if (!u) {
                                            throw new r("Expected group after '" + i.result.result + "'", this.lexer, l)
                                        }
                                    }
                                    var m;
                                    if (u.numArgs > 0) {
                                        var f = h.getGreediness(u.result.result);
                                        if (f > d) {
                                            m = this.parseFunction(l, t)
                                        } else {
                                            throw new r("Got function '" + u.result.result + "' as " + "argument to function '" + i.result.result + "'", this.lexer, u.result.position - 1)
                                        }
                                    } else {
                                        m = u.result
                                    }
                                    n.push(m.result);
                                    o.push(m.position);
                                    l = m.position
                                }
                                n.push(o);
                                s = h.funcs[a].handler.apply(this, n)
                            } else {
                                s = h.funcs[a].handler.apply(this, [a])
                            }
                            return new g(new c(s.type, s, t), l)
                        } else {
                            return i.result
                        }
                    } else {
                        return null
                    }
                };
                p.prototype.parseSpecialGroup = function (e, t, i, h) {
                    if (t === "color" || t === "size") {
                        var a = this.lexer.lex(e, i);
                        if (h && a.text !== "[") {
                            return null
                        }
                        this.expect(a, h ? "[" : "{");
                        var l = this.lexer.lex(a.position, t);
                        var s;
                        if (t === "color") {
                            s = l.text
                        } else {
                            s = l.data
                        }
                        var r = this.lexer.lex(l.position, i);
                        this.expect(r, h ? "]" : "}");
                        return new d(new g(new c(t, s, i), r.position), false)
                    } else if (t === "text") {
                        var p = this.lexer.lex(e, "whitespace");
                        e = p.position
                    }
                    if (h) {
                        return this.parseOptionalGroup(e, t)
                    } else {
                        return this.parseGroup(e, t)
                    }
                };
                p.prototype.parseGroup = function (e, t) {
                    var i = this.lexer.lex(e, t);
                    if (i.text === "{") {
                        var h = this.parseExpression(i.position, t, false, "}");
                        var a = this.lexer.lex(h.position, t);
                        this.expect(a, "}");
                        return new d(new g(new c("ordgroup", h.result, t), a.position), false)
                    } else {
                        return this.parseSymbol(e, t)
                    }
                };
                p.prototype.parseOptionalGroup = function (e, t) {
                    var i = this.lexer.lex(e, t);
                    if (i.text === "[") {
                        var h = this.parseExpression(i.position, t, false, "]");
                        var a = this.lexer.lex(h.position, t);
                        this.expect(a, "]");
                        return new d(new g(new c("ordgroup", h.result, t), a.position), false)
                    } else {
                        return null
                    }
                };
                p.prototype.parseSymbol = function (e, t) {
                    var i = this.lexer.lex(e, t);
                    if (h.funcs[i.text]) {
                        var a = h.funcs[i.text];
                        var s = a.argTypes;
                        if (s) {
                            s = s.slice();
                            for (var r = 0; r < s.length; r++) {
                                if (s[r] === "original") {
                                    s[r] = t
                                }
                            }
                        }
                        return new d(new g(i.text, i.position), true, a.allowedInText, a.numArgs, a.numOptionalArgs, s)
                    } else if (l[t][i.text]) {
                        return new d(new g(new c(l[t][i.text].group, i.text, t), i.position), false)
                    } else {
                        return null
                    }
                };
                t.exports = p
            }, {"./Lexer": 2, "./ParseError": 4, "./functions": 12, "./symbols": 14, "./utils": 15}], 6: [function (e, t, i) {
                function h(e, t, i, h) {
                    this.id = e;
                    this.size = t;
                    this.cramped = h;
                    this.sizeMultiplier = i
                }
                h.prototype.sup = function () {
                    return w[k[this.id]]
                };
                h.prototype.sub = function () {
                    return w[u[this.id]]
                };
                h.prototype.fracNum = function () {
                    return w[m[this.id]]
                };
                h.prototype.fracDen = function () {
                    return w[f[this.id]]
                };
                h.prototype.cramp = function () {
                    return w[v[this.id]]
                };
                h.prototype.cls = function () {
                    return n[this.size] + (this.cramped ? " cramped" : " uncramped")
                };
                h.prototype.reset = function () {
                    return o[this.size]
                };
                var a = 0;
                var l = 1;
                var s = 2;
                var r = 3;
                var p = 4;
                var c = 5;
                var g = 6;
                var d = 7;
                var n = ["displaystyle textstyle", "textstyle", "scriptstyle", "scriptscriptstyle"];
                var o = ["reset-textstyle", "reset-textstyle", "reset-scriptstyle", "reset-scriptscriptstyle"];
                var w = [new h(a, 0, 1, false), new h(l, 0, 1, true), new h(s, 1, 1, false), new h(r, 1, 1, true), new h(p, 2, .7, false), new h(c, 2, .7, true), new h(g, 3, .5, false), new h(d, 3, .5, true)];
                var k = [p, c, p, c, g, d, g, d];
                var u = [c, c, c, c, d, d, d, d];
                var m = [s, r, p, c, g, d, g, d];
                var f = [r, r, c, c, d, d, d, d];
                var v = [l, l, r, r, c, c, d, d];
                t.exports = {DISPLAY: w[a], TEXT: w[s], SCRIPT: w[p], SCRIPTSCRIPT: w[g]}
            }, {}], 7: [function (e, t, i) {
                var h = e("./domTree");
                var a = e("./fontMetrics");
                var l = e("./symbols");
                var s = function (e, t, i, s, r) {
                    if (l[i][e] && l[i][e].replace) {
                        e = l[i][e].replace
                    }
                    var p = a.getCharacterMetrics(e, t);
                    var c;
                    if (p) {
                        c = new h.symbolNode(e, p.height, p.depth, p.italic, p.skew, r)
                    } else {
                        typeof console !== "undefined" && console.warn("No character metrics for '" + e + "' in style '" + t + "'");
                        c = new h.symbolNode(e, 0, 0, 0, 0, r)
                    }
                    if (s) {
                        c.style.color = s
                    }
                    return c
                };
                var r = function (e, t, i, h) {
                    return s(e, "Math-Italic", t, i, h.concat(["mathit"]))
                };
                var p = function (e, t, i, h) {
                    if (l[t][e].font === "main") {
                        return s(e, "Main-Regular", t, i, h)
                    } else {
                        return s(e, "AMS-Regular", t, i, h.concat(["amsrm"]))
                    }
                };
                var c = function (e) {
                    var t = 0;
                    var i = 0;
                    var h = 0;
                    if (e.children) {
                        for (var a = 0; a < e.children.length; a++) {
                            if (e.children[a].height > t) {
                                t = e.children[a].height
                            }
                            if (e.children[a].depth > i) {
                                i = e.children[a].depth
                            }
                            if (e.children[a].maxFontSize > h) {
                                h = e.children[a].maxFontSize
                            }
                        }
                    }
                    e.height = t;
                    e.depth = i;
                    e.maxFontSize = h
                };
                var g = function (e, t, i) {
                    var a = new h.span(e, t);
                    c(a);
                    if (i) {
                        a.style.color = i
                    }
                    return a
                };
                var d = function (e) {
                    var t = new h.documentFragment(e);
                    c(t);
                    return t
                };
                var n = function (e, t) {
                    var i = g([], [new h.symbolNode("\u200b")]);
                    i.style.fontSize = t / e.style.sizeMultiplier + "em";
                    var a = g(["fontsize-ensurer", "reset-" + e.size, "size5"], [i]);
                    return a
                };
                var o = function (e, t, i, a) {
                    var l;
                    var s;
                    var r;
                    if (t === "individualShift") {
                        var p = e;
                        e = [p[0]];
                        l = -p[0].shift - p[0].elem.depth;
                        s = l;
                        for (r = 1; r < p.length; r++) {
                            var c = -p[r].shift - s - p[r].elem.depth;
                            var d = c - (p[r - 1].elem.height + p[r - 1].elem.depth);
                            s = s + c;
                            e.push({type: "kern", size: d});
                            e.push(p[r])
                        }
                    } else if (t === "top") {
                        var o = i;
                        for (r = 0; r < e.length; r++) {
                            if (e[r].type === "kern") {
                                o -= e[r].size
                            } else {
                                o -= e[r].elem.height + e[r].elem.depth
                            }
                        }
                        l = o
                    } else if (t === "bottom") {
                        l = -i
                    } else if (t === "shift") {
                        l = -e[0].elem.depth - i
                    } else if (t === "firstBaseline") {
                        l = -e[0].elem.depth
                    } else {
                        l = 0
                    }
                    var w = 0;
                    for (r = 0; r < e.length; r++) {
                        if (e[r].type === "elem") {
                            w = Math.max(w, e[r].elem.maxFontSize)
                        }
                    }
                    var k = n(a, w);
                    var u = [];
                    s = l;
                    for (r = 0; r < e.length; r++) {
                        if (e[r].type === "kern") {
                            s += e[r].size
                        } else {
                            var m = e[r].elem;
                            var f = -m.depth - s;
                            s += m.height + m.depth;
                            var v = g([], [k, m]);
                            v.height -= f;
                            v.depth += f;
                            v.style.top = f + "em";
                            u.push(v)
                        }
                    }
                    var y = g(["baseline-fix"], [k, new h.symbolNode("\u200b")]);
                    u.push(y);
                    var x = g(["vlist"], u);
                    x.height = Math.max(s, x.height);
                    x.depth = Math.max(-l, x.depth);
                    return x
                };
                t.exports = {makeSymbol: s, mathit: r, mathrm: p, makeSpan: g, makeFragment: d, makeVList: o}
            }, {"./domTree": 10, "./fontMetrics": 11, "./symbols": 14}], 8: [function (e, t, i) {
                var h = e("./Options");
                var a = e("./ParseError");
                var l = e("./Style");
                var s = e("./buildCommon");
                var r = e("./delimiter");
                var p = e("./domTree");
                var c = e("./fontMetrics");
                var g = e("./utils");
                var d = s.makeSpan;
                var n = function (e, t, i) {
                    var h = [];
                    for (var a = 0; a < e.length; a++) {
                        var l = e[a];
                        h.push(y(l, t, i));
                        i = l
                    }
                    return h
                };
                var o = {mathord: "mord", textord: "mord", bin: "mbin", rel: "mrel", text: "mord", open: "mopen", close: "mclose", inner: "minner", frac: "minner", spacing: "mord", punct: "mpunct", ordgroup: "mord", op: "mop", katex: "mord", overline: "mord", rule: "mord", leftright: "minner", sqrt: "mord", accent: "mord"};
                var w = function (e) {
                    if (e == null) {
                        return o.mathord
                    } else if (e.type === "supsub") {
                        return w(e.value.base)
                    } else if (e.type === "llap" || e.type === "rlap") {
                        return w(e.value)
                    } else if (e.type === "color") {
                        return w(e.value.value)
                    } else if (e.type === "sizing") {
                        return w(e.value.value)
                    } else if (e.type === "styling") {
                        return w(e.value.value)
                    } else if (e.type === "delimsizing") {
                        return o[e.value.delimType]
                    } else {
                        return o[e.type]
                    }
                };
                var k = function (e, t) {
                    if (!e) {
                        return false
                    } else if (e.type === "op") {
                        return e.value.limits && t.style.size === l.DISPLAY.size
                    } else if (e.type === "accent") {
                        return m(e.value.base)
                    } else {
                        return null
                    }
                };
                var u = function (e) {
                    if (!e) {
                        return false
                    } else if (e.type === "ordgroup") {
                        if (e.value.length === 1) {
                            return u(e.value[0])
                        } else {
                            return e
                        }
                    } else if (e.type === "color") {
                        if (e.value.value.length === 1) {
                            return u(e.value.value[0])
                        } else {
                            return e
                        }
                    } else {
                        return e
                    }
                };
                var m = function (e) {
                    var t = u(e);
                    return t.type === "mathord" || t.type === "textord" || t.type === "bin" || t.type === "rel" || t.type === "inner" || t.type === "open" || t.type === "close" || t.type === "punct"
                };
                var f = {mathord: function (e, t, i) {
                        return s.mathit(e.value, e.mode, t.getColor(), ["mord"])
                    }, textord: function (e, t, i) {
                        return s.mathrm(e.value, e.mode, t.getColor(), ["mord"])
                    }, bin: function (e, t, i) {
                        var h = "mbin";
                        var a = i;
                        while (a && a.type == "color") {
                            var l = a.value.value;
                            a = l[l.length - 1]
                        }
                        if (!i || g.contains(["mbin", "mopen", "mrel", "mop", "mpunct"], w(a))) {
                            e.type = "textord";
                            h = "mord"
                        }
                        return s.mathrm(e.value, e.mode, t.getColor(), [h])
                    }, rel: function (e, t, i) {
                        return s.mathrm(e.value, e.mode, t.getColor(), ["mrel"])
                    }, open: function (e, t, i) {
                        return s.mathrm(e.value, e.mode, t.getColor(), ["mopen"])
                    }, close: function (e, t, i) {
                        return s.mathrm(e.value, e.mode, t.getColor(), ["mclose"])
                    }, inner: function (e, t, i) {
                        return s.mathrm(e.value, e.mode, t.getColor(), ["minner"])
                    }, punct: function (e, t, i) {
                        return s.mathrm(e.value, e.mode, t.getColor(), ["mpunct"])
                    }, ordgroup: function (e, t, i) {
                        return d(["mord", t.style.cls()], n(e.value, t.reset()))
                    }, text: function (e, t, i) {
                        return d(["text", "mord", t.style.cls()], n(e.value.body, t.reset()))
                    }, color: function (e, t, i) {
                        var h = n(e.value.value, t.withColor(e.value.color), i);
                        return new s.makeFragment(h)
                    }, supsub: function (e, t, i) {
                        if (k(e.value.base, t)) {
                            return f[e.value.base.type](e, t, i)
                        }
                        var h = y(e.value.base, t.reset());
                        var a, r, g, n;
                        if (e.value.sup) {
                            g = y(e.value.sup, t.withStyle(t.style.sup()));
                            a = d([t.style.reset(), t.style.sup().cls()], [g])
                        }
                        if (e.value.sub) {
                            n = y(e.value.sub, t.withStyle(t.style.sub()));
                            r = d([t.style.reset(), t.style.sub().cls()], [n])
                        }
                        var o, u;
                        if (m(e.value.base)) {
                            o = 0;
                            u = 0
                        } else {
                            o = h.height - c.metrics.supDrop;
                            u = h.depth + c.metrics.subDrop
                        }
                        var v;
                        if (t.style === l.DISPLAY) {
                            v = c.metrics.sup1
                        } else if (t.style.cramped) {
                            v = c.metrics.sup3
                        } else {
                            v = c.metrics.sup2
                        }
                        var x = l.TEXT.sizeMultiplier * t.style.sizeMultiplier;
                        var b = .5 / c.metrics.ptPerEm / x + "em";
                        var z;
                        if (!e.value.sup) {
                            u = Math.max(u, c.metrics.sub1, n.height - .8 * c.metrics.xHeight);
                            z = s.makeVList([{type: "elem", elem: r}], "shift", u, t);
                            z.children[0].style.marginRight = b;
                            if (h instanceof p.symbolNode) {
                                z.children[0].style.marginLeft = -h.italic + "em"
                            }
                        } else if (!e.value.sub) {
                            o = Math.max(o, v, g.depth + .25 * c.metrics.xHeight);
                            z = s.makeVList([{type: "elem", elem: a}], "shift", -o, t);
                            z.children[0].style.marginRight = b
                        } else {
                            o = Math.max(o, v, g.depth + .25 * c.metrics.xHeight);
                            u = Math.max(u, c.metrics.sub2);
                            var S = c.metrics.defaultRuleThickness;
                            if (o - g.depth - (n.height - u) < 4 * S) {
                                u = 4 * S - (o - g.depth) + n.height;
                                var T = .8 * c.metrics.xHeight - (o - g.depth);
                                if (T > 0) {
                                    o += T;
                                    u -= T
                                }
                            }
                            z = s.makeVList([{type: "elem", elem: r, shift: u}, {type: "elem", elem: a, shift: -o}], "individualShift", null, t);
                            if (h instanceof p.symbolNode) {
                                z.children[0].style.marginLeft = -h.italic + "em"
                            }
                            z.children[0].style.marginRight = b;
                            z.children[1].style.marginRight = b
                        }
                        return d([w(e.value.base)], [h, z])
                    }, genfrac: function (e, t, i) {
                        var h = t.style;
                        if (e.value.size === "display") {
                            h = l.DISPLAY
                        } else if (e.value.size === "text") {
                            h = l.TEXT
                        }
                        var a = h.fracNum();
                        var p = h.fracDen();
                        var g = y(e.value.numer, t.withStyle(a));
                        var n = d([h.reset(), a.cls()], [g]);
                        var o = y(e.value.denom, t.withStyle(p));
                        var w = d([h.reset(), p.cls()], [o]);
                        var k;
                        if (e.value.hasBarLine) {
                            k = c.metrics.defaultRuleThickness / t.style.sizeMultiplier
                        } else {
                            k = 0
                        }
                        var u;
                        var m;
                        var f;
                        if (h.size === l.DISPLAY.size) {
                            u = c.metrics.num1;
                            if (k > 0) {
                                m = 3 * k
                            } else {
                                m = 7 * c.metrics.defaultRuleThickness
                            }
                            f = c.metrics.denom1
                        } else {
                            if (k > 0) {
                                u = c.metrics.num2;
                                m = k
                            } else {
                                u = c.metrics.num3;
                                m = 3 * c.metrics.defaultRuleThickness
                            }
                            f = c.metrics.denom2
                        }
                        var v;
                        if (k === 0) {
                            var x = u - g.depth - (o.height - f);
                            if (x < m) {
                                u += .5 * (m - x);
                                f += .5 * (m - x)
                            }
                            v = s.makeVList([{type: "elem", elem: w, shift: f}, {type: "elem", elem: n, shift: -u}], "individualShift", null, t)
                        } else {
                            var b = c.metrics.axisHeight;
                            if (u - g.depth - (b + .5 * k) < m) {
                                u += m - (u - g.depth - (b + .5 * k))
                            }
                            if (b - .5 * k - (o.height - f) < m) {
                                f += m - (b - .5 * k - (o.height - f))
                            }
                            var z = d([t.style.reset(), l.TEXT.cls(), "frac-line"]);
                            z.height = k;
                            var S = -(b - .5 * k);
                            v = s.makeVList([{type: "elem", elem: w, shift: f}, {type: "elem", elem: z, shift: S}, {type: "elem", elem: n, shift: -u}], "individualShift", null, t)
                        }
                        v.height *= h.sizeMultiplier / t.style.sizeMultiplier;
                        v.depth *= h.sizeMultiplier / t.style.sizeMultiplier;
                        var T = [d(["mfrac"], [v])];
                        var M;
                        if (h.size === l.DISPLAY.size) {
                            M = c.metrics.delim1
                        } else {
                            M = c.metrics.getDelim2(h)
                        }
                        if (e.value.leftDelim != null) {
                            T.unshift(r.customSizedDelim(e.value.leftDelim, M, true, t.withStyle(h), e.mode))
                        }
                        if (e.value.rightDelim != null) {
                            T.push(r.customSizedDelim(e.value.rightDelim, M, true, t.withStyle(h), e.mode))
                        }
                        return d(["minner", t.style.reset(), h.cls()], T, t.getColor())
                    }, spacing: function (e, t, i) {
                        if (e.value === "\\ " || e.value === "\\space" || e.value === " " || e.value === "~") {
                            return d(["mord", "mspace"], [s.mathrm(e.value, e.mode)])
                        } else {
                            var h = {"\\qquad": "qquad", "\\quad": "quad", "\\enspace": "enspace", "\\;": "thickspace", "\\:": "mediumspace", "\\,": "thinspace", "\\!": "negativethinspace"};
                            return d(["mord", "mspace", h[e.value]])
                        }
                    }, llap: function (e, t, i) {
                        var h = d(["inner"], [y(e.value.body, t.reset())]);
                        var a = d(["fix"], []);
                        return d(["llap", t.style.cls()], [h, a])
                    }, rlap: function (e, t, i) {
                        var h = d(["inner"], [y(e.value.body, t.reset())]);
                        var a = d(["fix"], []);
                        return d(["rlap", t.style.cls()], [h, a])
                    }, op: function (e, t, i) {
                        var h;
                        var a;
                        var r = false;
                        if (e.type === "supsub") {
                            h = e.value.sup;
                            a = e.value.sub;
                            e = e.value.base;
                            r = true
                        }
                        var p = ["\\smallint"];
                        var n = false;
                        if (t.style.size === l.DISPLAY.size && e.value.symbol && !g.contains(p, e.value.body)) {
                            n = true
                        }
                        var o;
                        var w = 0;
                        var k = 0;
                        if (e.value.symbol) {
                            var u = n ? "Size2-Regular" : "Size1-Regular";
                            o = s.makeSymbol(e.value.body, u, "math", t.getColor(), ["op-symbol", n ? "large-op" : "small-op", "mop"]);
                            w = (o.height - o.depth) / 2 - c.metrics.axisHeight * t.style.sizeMultiplier;
                            k = o.italic
                        } else {
                            var m = [];
                            for (var f = 1; f < e.value.body.length; f++) {
                                m.push(s.mathrm(e.value.body[f], e.mode))
                            }
                            o = d(["mop"], m, t.getColor())
                        }
                        if (r) {
                            o = d([], [o]);
                            var v, x, b, z;
                            if (h) {
                                var S = y(h, t.withStyle(t.style.sup()));
                                v = d([t.style.reset(), t.style.sup().cls()], [S]);
                                x = Math.max(c.metrics.bigOpSpacing1, c.metrics.bigOpSpacing3 - S.depth)
                            }
                            if (a) {
                                var T = y(a, t.withStyle(t.style.sub()));
                                b = d([t.style.reset(), t.style.sub().cls()], [T]);
                                z = Math.max(c.metrics.bigOpSpacing2, c.metrics.bigOpSpacing4 - T.height)
                            }
                            var M, R, C;
                            if (!h) {
                                R = o.height - w;
                                M = s.makeVList([{type: "kern", size: c.metrics.bigOpSpacing5}, {type: "elem", elem: b}, {type: "kern", size: z}, {type: "elem", elem: o}], "top", R, t);
                                M.children[0].style.marginLeft = -k + "em"
                            } else if (!a) {
                                C = o.depth + w;
                                M = s.makeVList([{type: "elem", elem: o}, {type: "kern", size: x}, {type: "elem", elem: v}, {type: "kern", size: c.metrics.bigOpSpacing5}], "bottom", C, t);
                                M.children[1].style.marginLeft = k + "em"
                            } else if (!h && !a) {
                                return o
                            } else {
                                C = c.metrics.bigOpSpacing5 + b.height + b.depth + z + o.depth + w;
                                M = s.makeVList([{type: "kern", size: c.metrics.bigOpSpacing5}, {type: "elem", elem: b}, {type: "kern", size: z}, {type: "elem", elem: o}, {type: "kern", size: x}, {type: "elem", elem: v}, {type: "kern", size: c.metrics.bigOpSpacing5}], "bottom", C, t);
                                M.children[0].style.marginLeft = -k + "em";
                                M.children[2].style.marginLeft = k + "em"
                            }
                            return d(["mop", "op-limits"], [M])
                        } else {
                            if (e.value.symbol) {
                                o.style.top = w + "em"
                            }
                            return o
                        }
                    }, katex: function (e, t, i) {
                        var h = d(["k"], [s.mathrm("K", e.mode)]);
                        var a = d(["a"], [s.mathrm("A", e.mode)]);
                        a.height = (a.height + .2) * .75;
                        a.depth = (a.height - .2) * .75;
                        var l = d(["t"], [s.mathrm("T", e.mode)]);
                        var r = d(["e"], [s.mathrm("E", e.mode)]);
                        r.height = r.height - .2155;
                        r.depth = r.depth + .2155;
                        var p = d(["x"], [s.mathrm("X", e.mode)]);
                        return d(["katex-logo"], [h, a, l, r, p], t.getColor())
                    }, overline: function (e, t, i) {
                        var h = y(e.value.body, t.withStyle(t.style.cramp()));
                        var a = c.metrics.defaultRuleThickness / t.style.sizeMultiplier;
                        var r = d([t.style.reset(), l.TEXT.cls(), "overline-line"]);
                        r.height = a;
                        r.maxFontSize = 1;
                        var p = s.makeVList([{type: "elem", elem: h}, {type: "kern", size: 3 * a}, {type: "elem", elem: r}, {type: "kern", size: a}], "firstBaseline", null, t);
                        return d(["overline", "mord"], [p], t.getColor())
                    }, sqrt: function (e, t, i) {
                        var h = y(e.value.body, t.withStyle(t.style.cramp()));
                        var a = c.metrics.defaultRuleThickness / t.style.sizeMultiplier;
                        var p = d([t.style.reset(), l.TEXT.cls(), "sqrt-line"], [], t.getColor());
                        p.height = a;
                        p.maxFontSize = 1;
                        var g = a;
                        if (t.style.id < l.TEXT.id) {
                            g = c.metrics.xHeight
                        }
                        var n = a + g / 4;
                        var o = (h.height + h.depth) * t.style.sizeMultiplier;
                        var w = o + n + a;
                        var k = d(["sqrt-sign"], [r.customSizedDelim("\\surd", w, false, t, e.mode)], t.getColor());
                        var u = k.height + k.depth - a;
                        if (u > h.height + h.depth + n) {
                            n = (n + u - h.height - h.depth) / 2
                        }
                        var m = -(h.height + n + a) + k.height;
                        k.style.top = m + "em";
                        k.height -= m;
                        k.depth += m;
                        var f;
                        if (h.height === 0 && h.depth === 0) {
                            f = d()
                        } else {
                            f = s.makeVList([{type: "elem", elem: h}, {type: "kern", size: n}, {type: "elem", elem: p}, {type: "kern", size: a}], "firstBaseline", null, t)
                        }
                        return d(["sqrt", "mord"], [k, f])
                    }, sizing: function (e, t, i) {
                        var h = n(e.value.value, t.withSize(e.value.size), i);
                        var a = d(["mord"], [d(["sizing", "reset-" + t.size, e.value.size, t.style.cls()], h)]);
                        var l = v[e.value.size];
                        a.maxFontSize = l * t.style.sizeMultiplier;
                        return a
                    }, styling: function (e, t, i) {
                        var h = {display: l.DISPLAY, text: l.TEXT, script: l.SCRIPT, scriptscript: l.SCRIPTSCRIPT};
                        var a = h[e.value.style];
                        var s = n(e.value.value, t.withStyle(a), i);
                        return d([t.style.reset(), a.cls()], s)
                    }, delimsizing: function (e, t, i) {
                        var h = e.value.value;
                        if (h === ".") {
                            return d([o[e.value.delimType]])
                        }
                        return d([o[e.value.delimType]], [r.sizedDelim(h, e.value.size, t, e.mode)])
                    }, leftright: function (e, t, i) {
                        var h = n(e.value.body, t.reset());
                        var a = 0;
                        var l = 0;
                        for (var s = 0; s < h.length; s++) {
                            a = Math.max(h[s].height, a);
                            l = Math.max(h[s].depth, l)
                        }
                        a *= t.style.sizeMultiplier;
                        l *= t.style.sizeMultiplier;
                        var p;
                        if (e.value.left === ".") {
                            p = d(["nulldelimiter"])
                        } else {
                            p = r.leftRightDelim(e.value.left, a, l, t, e.mode)
                        }
                        h.unshift(p);
                        var c;
                        if (e.value.right === ".") {
                            c = d(["nulldelimiter"])
                        } else {
                            c = r.leftRightDelim(e.value.right, a, l, t, e.mode)
                        }
                        h.push(c);
                        return d(["minner", t.style.cls()], h, t.getColor())
                    }, rule: function (e, t, i) {
                        var h = d(["mord", "rule"], [], t.getColor());
                        var a = 0;
                        if (e.value.shift) {
                            a = e.value.shift.number;
                            if (e.value.shift.unit === "ex") {
                                a *= c.metrics.xHeight
                            }
                        }
                        var l = e.value.width.number;
                        if (e.value.width.unit === "ex") {
                            l *= c.metrics.xHeight
                        }
                        var s = e.value.height.number;
                        if (e.value.height.unit === "ex") {
                            s *= c.metrics.xHeight
                        }
                        a /= t.style.sizeMultiplier;
                        l /= t.style.sizeMultiplier;
                        s /= t.style.sizeMultiplier;
                        h.style.borderRightWidth = l + "em";
                        h.style.borderTopWidth = s + "em";
                        h.style.bottom = a + "em";
                        h.width = l;
                        h.height = s + a;
                        h.depth = -a;
                        return h
                    }, accent: function (e, t, i) {
                        var h = e.value.base;
                        var a;
                        if (e.type === "supsub") {
                            var l = e;
                            e = l.value.base;
                            h = e.value.base;
                            l.value.base = h;
                            a = y(l, t.reset(), i)
                        }
                        var r = y(h, t.withStyle(t.style.cramp()));
                        var p;
                        if (m(h)) {
                            var g = u(h);
                            var n = y(g, t.withStyle(t.style.cramp()));
                            p = n.skew
                        } else {
                            p = 0
                        }
                        var o = Math.min(r.height, c.metrics.xHeight);
                        var w = s.makeSymbol(e.value.accent, "Main-Regular", "math", t.getColor());
                        w.italic = 0;
                        var k = e.value.accent === "\\vec" ? "accent-vec" : null;
                        var f = d(["accent-body", k], [d([], [w])]);
                        f = s.makeVList([{type: "elem", elem: r}, {type: "kern", size: -o}, {type: "elem", elem: f}], "firstBaseline", null, t);
                        f.children[1].style.marginLeft = 2 * p + "em";
                        var v = d(["mord", "accent"], [f]);
                        if (a) {
                            a.children[0] = v;
                            a.height = Math.max(v.height, a.height);
                            a.classes[0] = "mord";
                            return a
                        } else {
                            return v
                        }
                    }};
                var v = {size1: .5, size2: .7, size3: .8, size4: .9, size5: 1, size6: 1.2, size7: 1.44, size8: 1.73, size9: 2.07, size10: 2.49};
                var y = function (e, t, i) {
                    if (!e) {
                        return d()
                    }
                    if (f[e.type]) {
                        var h = f[e.type](e, t, i);
                        var l;
                        if (t.style !== t.parentStyle) {
                            l = t.style.sizeMultiplier / t.parentStyle.sizeMultiplier;
                            h.height *= l;
                            h.depth *= l
                        }
                        if (t.size !== t.parentSize) {
                            l = v[t.size] / v[t.parentSize];
                            h.height *= l;
                            h.depth *= l
                        }
                        return h
                    } else {
                        throw new a("Got group of unknown type: '" + e.type + "'")
                    }
                };
                var x = function (e) {
                    var t = new h(l.TEXT, "size5", "");
                    var i = n(e, t);
                    var a = d(["base", t.style.cls()], i);
                    var s = d(["strut"]);
                    var r = d(["strut", "bottom"]);
                    s.style.height = a.height + "em";
                    r.style.height = a.height + a.depth + "em";
                    r.style.verticalAlign = -a.depth + "em";
                    var p = d(["katex"], [d(["katex-inner"], [s, r, a])]);
                    return p
                };
                t.exports = x
            }, {"./Options": 3, "./ParseError": 4, "./Style": 6, "./buildCommon": 7, "./delimiter": 9, "./domTree": 10, "./fontMetrics": 11, "./utils": 15}], 9: [function (e, t, i) {
                var h = e("./ParseError");
                var a = e("./Style");
                var l = e("./buildCommon");
                var s = e("./fontMetrics");
                var r = e("./symbols");
                var p = e("./utils");
                var c = l.makeSpan;
                var g = function (e, t) {
                    if (r.math[e] && r.math[e].replace) {
                        return s.getCharacterMetrics(r.math[e].replace, t)
                    } else {
                        return s.getCharacterMetrics(e, t)
                    }
                };
                var d = function (e, t, i) {
                    return l.makeSymbol(e, "Size" + t + "-Regular", i)
                };
                var n = function (e, t, i) {
                    var h = c(["style-wrap", i.style.reset(), t.cls()], [e]);
                    var a = t.sizeMultiplier / i.style.sizeMultiplier;
                    h.height *= a;
                    h.depth *= a;
                    h.maxFontSize = t.sizeMultiplier;
                    return h
                };
                var o = function (e, t, i, h, a) {
                    var r = l.makeSymbol(e, "Main-Regular", a);
                    var p = n(r, t, h);
                    if (i) {
                        var c = (1 - h.style.sizeMultiplier / t.sizeMultiplier) * s.metrics.axisHeight;
                        p.style.top = c + "em";
                        p.height -= c;
                        p.depth += c
                    }
                    return p
                };
                var w = function (e, t, i, h, l) {
                    var r = d(e, t, l);
                    var p = n(c(["delimsizing", "size" + t], [r], h.getColor()), a.TEXT, h);
                    if (i) {
                        var g = (1 - h.style.sizeMultiplier) * s.metrics.axisHeight;
                        p.style.top = g + "em";
                        p.height -= g;
                        p.depth += g
                    }
                    return p
                };
                var k = function (e, t, i) {
                    var h;
                    if (t === "Size1-Regular") {
                        h = "delim-size1"
                    } else if (t === "Size4-Regular") {
                        h = "delim-size4"
                    }
                    var a = c(["delimsizinginner", h], [c([], [l.makeSymbol(e, t, i)])]);
                    return{type: "elem", elem: a}
                };
                var u = function (e, t, i, h, r) {
                    var p, d, o, w;
                    p = o = w = e;
                    d = null;
                    var u = "Size1-Regular";
                    if (e === "\\uparrow") {
                        o = w = "\u23d0"
                    } else if (e === "\\Uparrow") {
                        o = w = "\u2016"
                    } else if (e === "\\downarrow") {
                        p = o = "\u23d0"
                    } else if (e === "\\Downarrow") {
                        p = o = "\u2016"
                    } else if (e === "\\updownarrow") {
                        p = "\\uparrow";
                        o = "\u23d0";
                        w = "\\downarrow"
                    } else if (e === "\\Updownarrow") {
                        p = "\\Uparrow";
                        o = "\u2016";
                        w = "\\Downarrow"
                    } else if (e === "[" || e === "\\lbrack") {
                        p = "\u23a1";
                        o = "\u23a2";
                        w = "\u23a3";
                        u = "Size4-Regular"
                    } else if (e === "]" || e === "\\rbrack") {
                        p = "\u23a4";
                        o = "\u23a5";
                        w = "\u23a6";
                        u = "Size4-Regular"
                    } else if (e === "\\lfloor") {
                        o = p = "\u23a2";
                        w = "\u23a3";
                        u = "Size4-Regular"
                    } else if (e === "\\lceil") {
                        p = "\u23a1";
                        o = w = "\u23a2";
                        u = "Size4-Regular"
                    } else if (e === "\\rfloor") {
                        o = p = "\u23a5";
                        w = "\u23a6";
                        u = "Size4-Regular"
                    } else if (e === "\\rceil") {
                        p = "\u23a4";
                        o = w = "\u23a5";
                        u = "Size4-Regular"
                    } else if (e === "(") {
                        p = "\u239b";
                        o = "\u239c";
                        w = "\u239d";
                        u = "Size4-Regular"
                    } else if (e === ")") {
                        p = "\u239e";
                        o = "\u239f";
                        w = "\u23a0";
                        u = "Size4-Regular"
                    } else if (e === "\\{" || e === "\\lbrace") {
                        p = "\u23a7";
                        d = "\u23a8";
                        w = "\u23a9";
                        o = "\u23aa";
                        u = "Size4-Regular"
                    } else if (e === "\\}" || e === "\\rbrace") {
                        p = "\u23ab";
                        d = "\u23ac";
                        w = "\u23ad";
                        o = "\u23aa";
                        u = "Size4-Regular"
                    } else if (e === "\\surd") {
                        p = "\ue001";
                        w = "\u23b7";
                        o = "\ue000";
                        u = "Size4-Regular"
                    }
                    var m = g(p, u);
                    var f = m.height + m.depth;
                    var v = g(o, u);
                    var y = v.height + v.depth;
                    var x = g(w, u);
                    var b = x.height + x.depth;
                    var z, S;
                    if (d !== null) {
                        z = g(d, u);
                        S = z.height + z.depth
                    }
                    var T = f + b;
                    if (d !== null) {
                        T += S
                    }
                    while (T < t) {
                        T += y;
                        if (d !== null) {
                            T += y
                        }
                    }
                    var M = s.metrics.axisHeight;
                    if (i) {
                        M *= h.style.sizeMultiplier
                    }
                    var R = T / 2 - M;
                    var C = [];
                    C.push(k(w, u, r));
                    var A;
                    if (d === null) {
                        var E = T - f - b;
                        var P = Math.ceil(E / y);
                        for (A = 0; A < P; A++) {
                            C.push(k(o, u, r))
                        }
                    } else {
                        var I = T / 2 - f - S / 2;
                        var L = Math.ceil(I / y);
                        var O = T / 2 - f - S / 2;
                        var D = Math.ceil(O / y);
                        for (A = 0; A < L; A++) {
                            C.push(k(o, u, r))
                        }
                        C.push(k(d, u, r));
                        for (A = 0; A < D; A++) {
                            C.push(k(o, u, r))
                        }
                    }
                    C.push(k(p, u, r));
                    var q = l.makeVList(C, "bottom", R, h);
                    return n(c(["delimsizing", "mult"], [q], h.getColor()), a.TEXT, h)
                };
                var m = ["(", ")", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "\\lceil", "\\rceil", "\\surd"];
                var f = ["\\uparrow", "\\downarrow", "\\updownarrow", "\\Uparrow", "\\Downarrow", "\\Updownarrow", "|", "\\|", "\\vert", "\\Vert"];
                var v = ["<", ">", "\\langle", "\\rangle", "/", "\\backslash"];
                var y = [0, 1.2, 1.8, 2.4, 3];
                var x = function (e, t, i, a) {
                    if (e === "<") {
                        e = "\\langle"
                    } else if (e === ">") {
                        e = "\\rangle"
                    }
                    if (p.contains(m, e) || p.contains(v, e)) {
                        return w(e, t, false, i, a)
                    } else if (p.contains(f, e)) {
                        return u(e, y[t], false, i, a)
                    } else {
                        throw new h("Illegal delimiter: '" + e + "'")
                    }
                };
                var b = [{type: "small", style: a.SCRIPTSCRIPT}, {type: "small", style: a.SCRIPT}, {type: "small", style: a.TEXT}, {type: "large", size: 1}, {type: "large", size: 2}, {type: "large", size: 3}, {type: "large", size: 4}];
                var z = [{type: "small", style: a.SCRIPTSCRIPT}, {type: "small", style: a.SCRIPT}, {type: "small", style: a.TEXT}, {type: "stack"}];
                var S = [{type: "small", style: a.SCRIPTSCRIPT}, {type: "small", style: a.SCRIPT}, {type: "small", style: a.TEXT}, {type: "large", size: 1}, {type: "large", size: 2}, {type: "large", size: 3}, {type: "large", size: 4}, {type: "stack"}];
                var T = function (e) {
                    if (e.type === "small") {
                        return"Main-Regular"
                    } else if (e.type === "large") {
                        return"Size" + e.size + "-Regular"
                    } else if (e.type === "stack") {
                        return"Size4-Regular"
                    }
                };
                var M = function (e, t, i, h) {
                    var a = Math.min(2, 3 - h.style.size);
                    for (var l = a; l < i.length; l++) {
                        if (i[l].type === "stack") {
                            break
                        }
                        var s = g(e, T(i[l]));
                        var r = s.height + s.depth;
                        if (i[l].type === "small") {
                            r *= i[l].style.sizeMultiplier
                        }
                        if (r > t) {
                            return i[l]
                        }
                    }
                    return i[i.length - 1]
                };
                var R = function (e, t, i, h, a) {
                    if (e === "<") {
                        e = "\\langle"
                    } else if (e === ">") {
                        e = "\\rangle"
                    }
                    var l;
                    if (p.contains(v, e)) {
                        l = b
                    } else if (p.contains(m, e)) {
                        l = S
                    } else {
                        l = z
                    }
                    var s = M(e, t, l, h);
                    if (s.type === "small") {
                        return o(e, s.style, i, h, a)
                    } else if (s.type === "large") {
                        return w(e, s.size, i, h, a)
                    } else if (s.type === "stack") {
                        return u(e, t, i, h, a)
                    }
                };
                var C = function (e, t, i, h, a) {
                    var l = s.metrics.axisHeight * h.style.sizeMultiplier;
                    var r = 901;
                    var p = 5 / s.metrics.ptPerEm;
                    var c = Math.max(t - l, i + l);
                    var g = Math.max(c / 500 * r, 2 * c - p);
                    return R(e, g, true, h, a)
                };
                t.exports = {sizedDelim: x, customSizedDelim: R, leftRightDelim: C}
            }, {"./ParseError": 4, "./Style": 6, "./buildCommon": 7, "./fontMetrics": 11, "./symbols": 14, "./utils": 15}], 10: [function (e, t, i) {
                var h = e("./utils");
                var a = function (e) {
                    e = e.slice();
                    for (var t = e.length - 1; t >= 0; t--) {
                        if (!e[t]) {
                            e.splice(t, 1)
                        }
                    }
                    return e.join(" ")
                };
                function l(e, t, i, h, a, l) {
                    this.classes = e || [];
                    this.children = t || [];
                    this.height = i || 0;
                    this.depth = h || 0;
                    this.maxFontSize = a || 0;
                    this.style = l || {}
                }
                l.prototype.toNode = function () {
                    var e = document.createElement("span");
                    e.className = a(this.classes);
                    for (var t in this.style) {
                        if (this.style.hasOwnProperty(t)) {
                            e.style[t] = this.style[t]
                        }
                    }
                    for (var i = 0; i < this.children.length; i++) {
                        e.appendChild(this.children[i].toNode())
                    }
                    return e
                };
                l.prototype.toMarkup = function () {
                    var e = "<span";
                    if (this.classes.length) {
                        e += ' class="';
                        e += h.escape(a(this.classes));
                        e += '"'
                    }
                    var t = "";
                    for (var i in this.style) {
                        if (this.style.hasOwnProperty(i)) {
                            t += h.hyphenate(i) + ":" + this.style[i] + ";"
                        }
                    }
                    if (t) {
                        e += ' style="' + h.escape(t) + '"'
                    }
                    e += ">";
                    for (var l = 0; l < this.children.length; l++) {
                        e += this.children[l].toMarkup()
                    }
                    e += "</span>";
                    return e
                };
                function s(e, t, i, h) {
                    this.children = e || [];
                    this.height = t || 0;
                    this.depth = i || 0;
                    this.maxFontSize = h || 0
                }
                s.prototype.toNode = function () {
                    var e = document.createDocumentFragment();
                    for (var t = 0; t < this.children.length; t++) {
                        e.appendChild(this.children[t].toNode())
                    }
                    return e
                };
                s.prototype.toMarkup = function () {
                    var e = "";
                    for (var t = 0; t < this.children.length; t++) {
                        e += this.children[t].toMarkup()
                    }
                    return e
                };
                function r(e, t, i, h, a, l, s) {
                    this.value = e || "";
                    this.height = t || 0;
                    this.depth = i || 0;
                    this.italic = h || 0;
                    this.skew = a || 0;
                    this.classes = l || [];
                    this.style = s || {};
                    this.maxFontSize = 0
                }
                r.prototype.toNode = function () {
                    var e = document.createTextNode(this.value);
                    var t = null;
                    if (this.italic > 0) {
                        t = document.createElement("span");
                        t.style.marginRight = this.italic + "em"
                    }
                    if (this.classes.length > 0) {
                        t = t || document.createElement("span");
                        t.className = a(this.classes)
                    }
                    for (var i in this.style) {
                        if (this.style.hasOwnProperty(i)) {
                            t = t || document.createElement("span");
                            t.style[i] = this.style[i]
                        }
                    }
                    if (t) {
                        t.appendChild(e);
                        return t
                    } else {
                        return e
                    }
                };
                r.prototype.toMarkup = function () {
                    var e = false;
                    var t = "<span";
                    if (this.classes.length) {
                        e = true;
                        t += ' class="';
                        t += h.escape(a(this.classes));
                        t += '"'
                    }
                    var i = "";
                    if (this.italic > 0) {
                        i += "margin-right:" + this.italic + "em;"
                    }
                    for (var l in this.style) {
                        if (this.style.hasOwnProperty(l)) {
                            i += h.hyphenate(l) + ":" + this.style[l] + ";"
                        }
                    }
                    if (i) {
                        e = true;
                        t += ' style="' + h.escape(i) + '"'
                    }
                    var s = h.escape(this.value);
                    if (e) {
                        t += ">";
                        t += s;
                        t += "</span>";
                        return t
                    } else {
                        return s
                    }
                };
                t.exports = {span: l, documentFragment: s, symbolNode: r}
            }, {"./utils": 15}], 11: [function (e, t, i) {
                var h = e("./Style");
                var a = .025;
                var l = 0;
                var s = 0;
                var r = 0;
                var p = .431;
                var c = 1;
                var g = 0;
                var d = .677;
                var n = .394;
                var o = .444;
                var w = .686;
                var k = .345;
                var u = .413;
                var m = .363;
                var f = .289;
                var v = .15;
                var y = .247;
                var x = .386;
                var b = .05;
                var z = 2.39;
                var S = 1.01;
                var T = .81;
                var M = .71;
                var R = .25;
                var C = 0;
                var A = 0;
                var E = 0;
                var P = 0;
                var I = .431;
                var L = 1;
                var O = 0;
                var D = .04;
                var q = .111;
                var F = .166;
                var _ = .2;
                var B = .6;
                var G = .1;
                var N = 10;
                var X = {xHeight: p, quad: c, num1: d, num2: n, num3: o, denom1: w, denom2: k, sup1: u, sup2: m, sup3: f, sub1: v, sub2: y, supDrop: x, subDrop: b, axisHeight: R, defaultRuleThickness: D, bigOpSpacing1: q, bigOpSpacing2: F, bigOpSpacing3: _, bigOpSpacing4: B, bigOpSpacing5: G, ptPerEm: N, delim1: z, getDelim2: function (e) {
                        if (e.size === h.TEXT.size) {
                            return S
                        } else if (e.size === h.SCRIPT.size) {
                            return T
                        } else if (e.size === h.SCRIPTSCRIPT.size) {
                            return M
                        }
                        throw new Error("Unexpected style size: " + e.size)
                    }};
                var H = {"AMS-Regular": {10003: {depth: 0, height: .69224, italic: 0, skew: 0}, 10016: {depth: 0, height: .69224, italic: 0, skew: 0}, 1008: {depth: 0, height: .43056, italic: .04028, skew: 0}, 107: {depth: 0, height: .68889, italic: 0, skew: 0}, 10731: {depth: .11111, height: .69224, italic: 0, skew: 0}, 10846: {depth: .19444, height: .75583, italic: 0, skew: 0}, 10877: {depth: .13667, height: .63667, italic: 0, skew: 0}, 10878: {depth: .13667, height: .63667, italic: 0, skew: 0}, 10885: {depth: .25583, height: .75583, italic: 0, skew: 0}, 10886: {depth: .25583, height: .75583, italic: 0, skew: 0}, 10887: {depth: .13597, height: .63597, italic: 0, skew: 0}, 10888: {depth: .13597, height: .63597, italic: 0, skew: 0}, 10889: {depth: .26167, height: .75726, italic: 0, skew: 0}, 10890: {depth: .26167, height: .75726, italic: 0, skew: 0}, 10891: {depth: .48256, height: .98256, italic: 0, skew: 0}, 10892: {depth: .48256, height: .98256, italic: 0, skew: 0}, 10901: {depth: .13667, height: .63667, italic: 0, skew: 0}, 10902: {depth: .13667, height: .63667, italic: 0, skew: 0}, 10933: {depth: .25142, height: .75726, italic: 0, skew: 0}, 10934: {depth: .25142, height: .75726, italic: 0, skew: 0}, 10935: {depth: .26167, height: .75726, italic: 0, skew: 0}, 10936: {depth: .26167, height: .75726, italic: 0, skew: 0}, 10937: {depth: .26167, height: .75726, italic: 0, skew: 0}, 10938: {depth: .26167, height: .75726, italic: 0, skew: 0}, 10949: {depth: .25583, height: .75583, italic: 0, skew: 0}, 10950: {depth: .25583, height: .75583, italic: 0, skew: 0}, 10955: {depth: .28481, height: .79383, italic: 0, skew: 0}, 10956: {depth: .28481, height: .79383, italic: 0, skew: 0}, 165: {depth: 0, height: .675, italic: .025, skew: 0}, 174: {depth: .15559, height: .69224, italic: 0, skew: 0}, 240: {depth: 0, height: .68889, italic: 0, skew: 0}, 295: {depth: 0, height: .68889, italic: 0, skew: 0}, 57350: {depth: .08167, height: .58167, italic: 0, skew: 0}, 57351: {depth: .08167, height: .58167, italic: 0, skew: 0}, 57352: {depth: .08167, height: .58167, italic: 0, skew: 0}, 57353: {depth: 0, height: .43056, italic: .04028, skew: 0}, 57356: {depth: .25142, height: .75726, italic: 0, skew: 0}, 57357: {depth: .25142, height: .75726, italic: 0, skew: 0}, 57358: {depth: .41951, height: .91951, italic: 0, skew: 0}, 57359: {depth: .30274, height: .79383, italic: 0, skew: 0}, 57360: {depth: .30274, height: .79383, italic: 0, skew: 0}, 57361: {depth: .41951, height: .91951, italic: 0, skew: 0}, 57366: {depth: .25142, height: .75726, italic: 0, skew: 0}, 57367: {depth: .25142, height: .75726, italic: 0, skew: 0}, 57368: {depth: .25142, height: .75726, italic: 0, skew: 0}, 57369: {depth: .25142, height: .75726, italic: 0, skew: 0}, 57370: {depth: .13597, height: .63597, italic: 0, skew: 0}, 57371: {depth: .13597, height: .63597, italic: 0, skew: 0}, 65: {depth: 0, height: .68889, italic: 0, skew: 0}, 66: {depth: 0, height: .68889, italic: 0, skew: 0}, 67: {depth: 0, height: .68889, italic: 0, skew: 0}, 68: {depth: 0, height: .68889, italic: 0, skew: 0}, 69: {depth: 0, height: .68889, italic: 0, skew: 0}, 70: {depth: 0, height: .68889, italic: 0, skew: 0}, 71: {depth: 0, height: .68889, italic: 0, skew: 0}, 710: {depth: 0, height: .825, italic: 0, skew: 0}, 72: {depth: 0, height: .68889, italic: 0, skew: 0}, 73: {depth: 0, height: .68889, italic: 0, skew: 0}, 732: {depth: 0, height: .9, italic: 0, skew: 0}, 74: {depth: .16667, height: .68889, italic: 0, skew: 0}, 75: {depth: 0, height: .68889, italic: 0, skew: 0}, 76: {depth: 0, height: .68889, italic: 0, skew: 0}, 77: {depth: 0, height: .68889, italic: 0, skew: 0}, 770: {depth: 0, height: .825, italic: 0, skew: 0}, 771: {depth: 0, height: .9, italic: 0, skew: 0}, 78: {depth: 0, height: .68889, italic: 0, skew: 0}, 79: {depth: .16667, height: .68889, italic: 0, skew: 0}, 80: {depth: 0, height: .68889, italic: 0, skew: 0}, 81: {depth: .16667, height: .68889, italic: 0, skew: 0}, 82: {depth: 0, height: .68889, italic: 0, skew: 0}, 8245: {depth: 0, height: .54986, italic: 0, skew: 0}, 83: {depth: 0, height: .68889, italic: 0, skew: 0}, 84: {depth: 0, height: .68889, italic: 0, skew: 0}, 8463: {depth: 0, height: .68889, italic: 0, skew: 0}, 8487: {depth: 0, height: .68889, italic: 0, skew: 0}, 8498: {depth: 0, height: .68889, italic: 0, skew: 0}, 85: {depth: 0, height: .68889, italic: 0, skew: 0}, 8502: {depth: 0, height: .68889, italic: 0, skew: 0}, 8503: {depth: 0, height: .68889, italic: 0, skew: 0}, 8504: {depth: 0, height: .68889, italic: 0, skew: 0}, 8513: {depth: 0, height: .68889, italic: 0, skew: 0}, 8592: {depth: -.03598, height: .46402, italic: 0, skew: 0}, 8594: {depth: -.03598, height: .46402, italic: 0, skew: 0}, 86: {depth: 0, height: .68889, italic: 0, skew: 0}, 8602: {depth: -.13313, height: .36687, italic: 0, skew: 0}, 8603: {depth: -.13313, height: .36687, italic: 0, skew: 0}, 8606: {depth: .01354, height: .52239, italic: 0, skew: 0}, 8608: {depth: .01354, height: .52239, italic: 0, skew: 0}, 8610: {depth: .01354, height: .52239, italic: 0, skew: 0}, 8611: {depth: .01354, height: .52239, italic: 0, skew: 0}, 8619: {depth: 0, height: .54986, italic: 0, skew: 0}, 8620: {depth: 0, height: .54986, italic: 0, skew: 0}, 8621: {depth: -.13313, height: .37788, italic: 0, skew: 0}, 8622: {depth: -.13313, height: .36687, italic: 0, skew: 0}, 8624: {depth: 0, height: .69224, italic: 0, skew: 0}, 8625: {depth: 0, height: .69224, italic: 0, skew: 0}, 8630: {depth: 0, height: .43056, italic: 0, skew: 0}, 8631: {depth: 0, height: .43056, italic: 0, skew: 0}, 8634: {depth: .08198, height: .58198, italic: 0, skew: 0}, 8635: {depth: .08198, height: .58198, italic: 0, skew: 0}, 8638: {depth: .19444, height: .69224, italic: 0, skew: 0}, 8639: {depth: .19444, height: .69224, italic: 0, skew: 0}, 8642: {depth: .19444, height: .69224, italic: 0, skew: 0}, 8643: {depth: .19444, height: .69224, italic: 0, skew: 0}, 8644: {depth: .1808, height: .675, italic: 0, skew: 0}, 8646: {depth: .1808, height: .675, italic: 0, skew: 0}, 8647: {depth: .1808, height: .675, italic: 0, skew: 0}, 8648: {depth: .19444, height: .69224, italic: 0, skew: 0}, 8649: {depth: .1808, height: .675, italic: 0, skew: 0}, 8650: {depth: .19444, height: .69224, italic: 0, skew: 0}, 8651: {depth: .01354, height: .52239, italic: 0, skew: 0}, 8652: {depth: .01354, height: .52239, italic: 0, skew: 0}, 8653: {depth: -.13313, height: .36687, italic: 0, skew: 0}, 8654: {depth: -.13313, height: .36687, italic: 0, skew: 0}, 8655: {depth: -.13313, height: .36687, italic: 0, skew: 0}, 8666: {depth: .13667, height: .63667, italic: 0, skew: 0}, 8667: {depth: .13667, height: .63667, italic: 0, skew: 0}, 8669: {depth: -.13313, height: .37788, italic: 0, skew: 0}, 87: {depth: 0, height: .68889, italic: 0, skew: 0}, 8705: {depth: 0, height: .825, italic: 0, skew: 0}, 8708: {depth: 0, height: .68889, italic: 0, skew: 0}, 8709: {depth: .08167, height: .58167, italic: 0, skew: 0}, 8717: {depth: 0, height: .43056, italic: 0, skew: 0}, 8722: {depth: -.03598, height: .46402, italic: 0, skew: 0}, 8724: {depth: .08198, height: .69224, italic: 0, skew: 0}, 8726: {depth: .08167, height: .58167, italic: 0, skew: 0}, 8733: {depth: 0, height: .69224, italic: 0, skew: 0}, 8736: {depth: 0, height: .69224, italic: 0, skew: 0}, 8737: {depth: 0, height: .69224, italic: 0, skew: 0}, 8738: {depth: .03517, height: .52239, italic: 0, skew: 0}, 8739: {depth: .08167, height: .58167, italic: 0, skew: 0}, 8740: {depth: .25142, height: .74111, italic: 0, skew: 0}, 8741: {depth: .08167, height: .58167, italic: 0, skew: 0}, 8742: {depth: .25142, height: .74111, italic: 0, skew: 0}, 8756: {depth: 0, height: .69224, italic: 0, skew: 0}, 8757: {depth: 0, height: .69224, italic: 0, skew: 0}, 8764: {depth: -.13313, height: .36687, italic: 0, skew: 0}, 8765: {depth: -.13313, height: .37788, italic: 0, skew: 0}, 8769: {depth: -.13313, height: .36687, italic: 0, skew: 0}, 8770: {depth: -.03625, height: .46375, italic: 0, skew: 0}, 8774: {depth: .30274, height: .79383, italic: 0, skew: 0}, 8776: {depth: -.01688, height: .48312, italic: 0, skew: 0}, 8778: {depth: .08167, height: .58167, italic: 0, skew: 0}, 8782: {depth: .06062, height: .54986, italic: 0, skew: 0}, 8783: {depth: .06062, height: .54986, italic: 0, skew: 0}, 8785: {depth: .08198, height: .58198, italic: 0, skew: 0}, 8786: {depth: .08198, height: .58198, italic: 0, skew: 0}, 8787: {depth: .08198, height: .58198, italic: 0, skew: 0}, 8790: {depth: 0, height: .69224, italic: 0, skew: 0}, 8791: {depth: .22958, height: .72958, italic: 0, skew: 0}, 8796: {depth: .08198, height: .91667, italic: 0, skew: 0}, 88: {depth: 0, height: .68889, italic: 0, skew: 0}, 8806: {depth: .25583, height: .75583, italic: 0, skew: 0}, 8807: {depth: .25583, height: .75583, italic: 0, skew: 0}, 8808: {depth: .25142, height: .75726, italic: 0, skew: 0}, 8809: {depth: .25142, height: .75726, italic: 0, skew: 0}, 8812: {depth: .25583, height: .75583, italic: 0, skew: 0}, 8814: {depth: .20576, height: .70576, italic: 0, skew: 0}, 8815: {depth: .20576, height: .70576, italic: 0, skew: 0}, 8816: {depth: .30274, height: .79383, italic: 0, skew: 0}, 8817: {depth: .30274, height: .79383, italic: 0, skew: 0}, 8818: {depth: .22958, height: .72958, italic: 0, skew: 0}, 8819: {depth: .22958, height: .72958, italic: 0, skew: 0}, 8822: {depth: .1808, height: .675, italic: 0, skew: 0}, 8823: {depth: .1808, height: .675, italic: 0, skew: 0}, 8828: {depth: .13667, height: .63667, italic: 0, skew: 0}, 8829: {depth: .13667, height: .63667, italic: 0, skew: 0}, 8830: {depth: .22958, height: .72958, italic: 0, skew: 0}, 8831: {depth: .22958, height: .72958, italic: 0, skew: 0}, 8832: {depth: .20576, height: .70576, italic: 0, skew: 0}, 8833: {depth: .20576, height: .70576, italic: 0, skew: 0}, 8840: {depth: .30274, height: .79383, italic: 0, skew: 0}, 8841: {depth: .30274, height: .79383, italic: 0, skew: 0}, 8842: {depth: .13597, height: .63597, italic: 0, skew: 0}, 8843: {depth: .13597, height: .63597, italic: 0, skew: 0}, 8847: {depth: .03517, height: .54986, italic: 0, skew: 0}, 8848: {depth: .03517, height: .54986, italic: 0, skew: 0}, 8858: {depth: .08198, height: .58198, italic: 0, skew: 0}, 8859: {depth: .08198, height: .58198, italic: 0, skew: 0}, 8861: {depth: .08198, height: .58198, italic: 0, skew: 0}, 8862: {depth: 0, height: .675, italic: 0, skew: 0}, 8863: {depth: 0, height: .675, italic: 0, skew: 0}, 8864: {depth: 0, height: .675, italic: 0, skew: 0}, 8865: {depth: 0, height: .675, italic: 0, skew: 0}, 8872: {depth: 0, height: .69224, italic: 0, skew: 0}, 8873: {depth: 0, height: .69224, italic: 0, skew: 0}, 8874: {depth: 0, height: .69224, italic: 0, skew: 0}, 8876: {depth: 0, height: .68889, italic: 0, skew: 0}, 8877: {depth: 0, height: .68889, italic: 0, skew: 0}, 8878: {depth: 0, height: .68889, italic: 0, skew: 0}, 8879: {depth: 0, height: .68889, italic: 0, skew: 0}, 8882: {depth: .03517, height: .54986, italic: 0, skew: 0}, 8883: {depth: .03517, height: .54986, italic: 0, skew: 0}, 8884: {depth: .13667, height: .63667, italic: 0, skew: 0}, 8885: {depth: .13667, height: .63667, italic: 0, skew: 0}, 8888: {depth: 0, height: .54986, italic: 0, skew: 0}, 8890: {depth: .19444, height: .43056, italic: 0, skew: 0}, 8891: {depth: .19444, height: .69224, italic: 0, skew: 0}, 8892: {depth: .19444, height: .69224, italic: 0, skew: 0}, 89: {depth: 0, height: .68889, italic: 0, skew: 0}, 8901: {depth: 0, height: .54986, italic: 0, skew: 0}, 8903: {depth: .08167, height: .58167, italic: 0, skew: 0}, 8905: {depth: .08167, height: .58167, italic: 0, skew: 0}, 8906: {depth: .08167, height: .58167, italic: 0, skew: 0}, 8907: {depth: 0, height: .69224, italic: 0, skew: 0}, 8908: {depth: 0, height: .69224, italic: 0, skew: 0}, 8909: {depth: -.03598, height: .46402, italic: 0, skew: 0}, 8910: {depth: 0, height: .54986, italic: 0, skew: 0}, 8911: {depth: 0, height: .54986, italic: 0, skew: 0}, 8912: {depth: .03517, height: .54986, italic: 0, skew: 0}, 8913: {depth: .03517, height: .54986, italic: 0, skew: 0}, 8914: {depth: 0, height: .54986, italic: 0, skew: 0}, 8915: {depth: 0, height: .54986, italic: 0, skew: 0}, 8916: {depth: 0, height: .69224, italic: 0, skew: 0}, 8918: {depth: .0391, height: .5391, italic: 0, skew: 0}, 8919: {depth: .0391, height: .5391, italic: 0, skew: 0}, 8920: {depth: .03517, height: .54986, italic: 0, skew: 0}, 8921: {depth: .03517, height: .54986, italic: 0, skew: 0}, 8922: {depth: .38569, height: .88569, italic: 0, skew: 0}, 8923: {depth: .38569, height: .88569, italic: 0, skew: 0}, 8926: {depth: .13667, height: .63667, italic: 0, skew: 0}, 8927: {depth: .13667, height: .63667, italic: 0, skew: 0}, 8928: {depth: .30274, height: .79383, italic: 0, skew: 0}, 8929: {depth: .30274, height: .79383, italic: 0, skew: 0}, 8934: {depth: .23222, height: .74111, italic: 0, skew: 0}, 8935: {depth: .23222, height: .74111, italic: 0, skew: 0}, 8936: {depth: .23222, height: .74111, italic: 0, skew: 0}, 8937: {depth: .23222, height: .74111, italic: 0, skew: 0}, 8938: {depth: .20576, height: .70576, italic: 0, skew: 0}, 8939: {depth: .20576, height: .70576, italic: 0, skew: 0}, 8940: {depth: .30274, height: .79383, italic: 0, skew: 0}, 8941: {depth: .30274, height: .79383, italic: 0, skew: 0}, 8994: {depth: .19444, height: .69224, italic: 0, skew: 0}, 8995: {depth: .19444, height: .69224, italic: 0, skew: 0}, 90: {depth: 0, height: .68889, italic: 0, skew: 0}, 9416: {depth: .15559, height: .69224, italic: 0, skew: 0}, 9484: {depth: 0, height: .69224, italic: 0, skew: 0}, 9488: {depth: 0, height: .69224, italic: 0, skew: 0}, 9492: {depth: 0, height: .37788, italic: 0, skew: 0}, 9496: {depth: 0, height: .37788, italic: 0, skew: 0}, 9585: {depth: .19444, height: .68889, italic: 0, skew: 0}, 9586: {depth: .19444, height: .74111, italic: 0, skew: 0}, 9632: {depth: 0, height: .675, italic: 0, skew: 0}, 9633: {depth: 0, height: .675, italic: 0, skew: 0}, 9650: {depth: 0, height: .54986, italic: 0, skew: 0}, 9651: {depth: 0, height: .54986, italic: 0, skew: 0}, 9654: {depth: .03517, height: .54986, italic: 0, skew: 0}, 9660: {depth: 0, height: .54986, italic: 0, skew: 0}, 9661: {depth: 0, height: .54986, italic: 0, skew: 0}, 9664: {depth: .03517, height: .54986, italic: 0, skew: 0}, 9674: {depth: .11111, height: .69224, italic: 0, skew: 0}, 9733: {depth: .19444, height: .69224, italic: 0, skew: 0}, 989: {depth: .08167, height: .58167, italic: 0, skew: 0}}, "Main-Bold": {100: {depth: 0, height: .69444, italic: 0, skew: 0}, 101: {depth: 0, height: .44444, italic: 0, skew: 0}, 102: {depth: 0, height: .69444, italic: .10903, skew: 0}, 10216: {depth: .25, height: .75, italic: 0, skew: 0}, 10217: {depth: .25, height: .75, italic: 0, skew: 0}, 103: {depth: .19444, height: .44444, italic: .01597, skew: 0}, 104: {depth: 0, height: .69444, italic: 0, skew: 0}, 105: {depth: 0, height: .69444, italic: 0, skew: 0}, 106: {depth: .19444, height: .69444, italic: 0, skew: 0}, 107: {depth: 0, height: .69444, italic: 0, skew: 0}, 108: {depth: 0, height: .69444, italic: 0, skew: 0}, 10815: {depth: 0, height: .68611, italic: 0, skew: 0}, 109: {depth: 0, height: .44444, italic: 0, skew: 0}, 10927: {depth: .19667, height: .69667, italic: 0, skew: 0}, 10928: {depth: .19667, height: .69667, italic: 0, skew: 0}, 110: {depth: 0, height: .44444, italic: 0, skew: 0}, 111: {depth: 0, height: .44444, italic: 0, skew: 0}, 112: {depth: .19444, height: .44444, italic: 0, skew: 0}, 113: {depth: .19444, height: .44444, italic: 0, skew: 0}, 114: {depth: 0, height: .44444, italic: 0, skew: 0}, 115: {depth: 0, height: .44444, italic: 0, skew: 0}, 116: {depth: 0, height: .63492, italic: 0, skew: 0}, 117: {depth: 0, height: .44444, italic: 0, skew: 0}, 118: {depth: 0, height: .44444, italic: .01597, skew: 0}, 119: {depth: 0, height: .44444, italic: .01597, skew: 0}, 120: {depth: 0, height: .44444, italic: 0, skew: 0}, 121: {depth: .19444, height: .44444, italic: .01597, skew: 0}, 122: {depth: 0, height: .44444, italic: 0, skew: 0}, 123: {depth: .25, height: .75, italic: 0, skew: 0}, 124: {depth: .25, height: .75, italic: 0, skew: 0}, 125: {depth: .25, height: .75, italic: 0, skew: 0}, 126: {depth: .35, height: .34444, italic: 0, skew: 0}, 168: {depth: 0, height: .69444, italic: 0, skew: 0}, 172: {depth: 0, height: .44444, italic: 0, skew: 0}, 175: {depth: 0, height: .59611, italic: 0, skew: 0}, 176: {depth: 0, height: .69444, italic: 0, skew: 0}, 177: {depth: .13333, height: .63333, italic: 0, skew: 0}, 180: {depth: 0, height: .69444, italic: 0, skew: 0}, 215: {depth: .13333, height: .63333, italic: 0, skew: 0}, 247: {depth: .13333, height: .63333, italic: 0, skew: 0}, 305: {depth: 0, height: .44444, italic: 0, skew: 0}, 33: {depth: 0, height: .69444, italic: 0, skew: 0}, 34: {depth: 0, height: .69444, italic: 0, skew: 0}, 35: {depth: .19444, height: .69444, italic: 0, skew: 0}, 36: {depth: .05556, height: .75, italic: 0, skew: 0}, 37: {depth: .05556, height: .75, italic: 0, skew: 0}, 38: {depth: 0, height: .69444, italic: 0, skew: 0}, 39: {depth: 0, height: .69444, italic: 0, skew: 0}, 40: {depth: .25, height: .75, italic: 0, skew: 0}, 41: {depth: .25, height: .75, italic: 0, skew: 0}, 42: {depth: 0, height: .75, italic: 0, skew: 0}, 43: {depth: .13333, height: .63333, italic: 0, skew: 0}, 44: {depth: .19444, height: .15556, italic: 0, skew: 0}, 45: {depth: 0, height: .44444, italic: 0, skew: 0}, 46: {depth: 0, height: .15556, italic: 0, skew: 0}, 47: {depth: .25, height: .75, italic: 0, skew: 0}, 48: {depth: 0, height: .64444, italic: 0, skew: 0}, 49: {depth: 0, height: .64444, italic: 0, skew: 0}, 50: {depth: 0, height: .64444, italic: 0, skew: 0}, 51: {depth: 0, height: .64444, italic: 0, skew: 0}, 52: {depth: 0, height: .64444, italic: 0, skew: 0}, 53: {depth: 0, height: .64444, italic: 0, skew: 0}, 54: {depth: 0, height: .64444, italic: 0, skew: 0}, 55: {depth: 0, height: .64444, italic: 0, skew: 0}, 56: {depth: 0, height: .64444, italic: 0, skew: 0}, 567: {depth: .19444, height: .44444, italic: 0, skew: 0}, 57: {depth: 0, height: .64444, italic: 0, skew: 0}, 58: {depth: 0, height: .44444, italic: 0, skew: 0}, 59: {depth: .19444, height: .44444, italic: 0, skew: 0}, 60: {depth: .08556, height: .58556, italic: 0, skew: 0}, 61: {depth: -.10889, height: .39111, italic: 0, skew: 0}, 62: {depth: .08556, height: .58556, italic: 0, skew: 0}, 63: {depth: 0, height: .69444, italic: 0, skew: 0}, 64: {depth: 0, height: .69444, italic: 0, skew: 0}, 65: {depth: 0, height: .68611, italic: 0, skew: 0}, 66: {depth: 0, height: .68611, italic: 0, skew: 0}, 67: {depth: 0, height: .68611, italic: 0, skew: 0}, 68: {depth: 0, height: .68611, italic: 0, skew: 0}, 69: {depth: 0, height: .68611, italic: 0, skew: 0}, 70: {depth: 0, height: .68611, italic: 0, skew: 0}, 71: {depth: 0, height: .68611, italic: 0, skew: 0}, 710: {depth: 0, height: .69444, italic: 0, skew: 0}, 711: {depth: 0, height: .63194, italic: 0, skew: 0}, 713: {depth: 0, height: .59611, italic: 0, skew: 0}, 714: {depth: 0, height: .69444, italic: 0, skew: 0}, 715: {depth: 0, height: .69444, italic: 0, skew: 0}, 72: {depth: 0, height: .68611, italic: 0, skew: 0}, 728: {depth: 0, height: .69444, italic: 0, skew: 0}, 729: {depth: 0, height: .69444, italic: 0, skew: 0}, 73: {depth: 0, height: .68611, italic: 0, skew: 0}, 730: {depth: 0, height: .69444, italic: 0, skew: 0}, 732: {depth: 0, height: .69444, italic: 0, skew: 0}, 74: {depth: 0, height: .68611, italic: 0, skew: 0}, 75: {depth: 0, height: .68611, italic: 0, skew: 0}, 76: {depth: 0, height: .68611, italic: 0, skew: 0}, 768: {depth: 0, height: .69444, italic: 0, skew: 0}, 769: {depth: 0, height: .69444, italic: 0, skew: 0}, 77: {depth: 0, height: .68611, italic: 0, skew: 0}, 770: {depth: 0, height: .69444, italic: 0, skew: 0}, 771: {depth: 0, height: .69444, italic: 0, skew: 0}, 772: {depth: 0, height: .59611, italic: 0, skew: 0}, 774: {depth: 0, height: .69444, italic: 0, skew: 0}, 775: {depth: 0, height: .69444, italic: 0, skew: 0}, 776: {depth: 0, height: .69444, italic: 0, skew: 0}, 778: {depth: 0, height: .69444, italic: 0, skew: 0}, 779: {depth: 0, height: .69444, italic: 0, skew: 0}, 78: {depth: 0, height: .68611, italic: 0, skew: 0}, 780: {depth: 0, height: .63194, italic: 0, skew: 0}, 79: {depth: 0, height: .68611, italic: 0, skew: 0}, 80: {depth: 0, height: .68611, italic: 0, skew: 0}, 81: {depth: .19444, height: .68611, italic: 0, skew: 0}, 82: {depth: 0, height: .68611, italic: 0, skew: 0}, 8211: {depth: 0, height: .44444, italic: .03194, skew: 0}, 8212: {depth: 0, height: .44444, italic: .03194, skew: 0}, 8216: {depth: 0, height: .69444, italic: 0, skew: 0}, 8217: {depth: 0, height: .69444, italic: 0, skew: 0}, 8220: {depth: 0, height: .69444, italic: 0, skew: 0}, 8221: {depth: 0, height: .69444, italic: 0, skew: 0}, 8224: {depth: .19444, height: .69444, italic: 0, skew: 0}, 8225: {depth: .19444, height: .69444, italic: 0, skew: 0}, 824: {depth: .19444, height: .69444, italic: 0, skew: 0}, 8242: {depth: 0, height: .55556, italic: 0, skew: 0}, 83: {depth: 0, height: .68611, italic: 0, skew: 0}, 84: {depth: 0, height: .68611, italic: 0, skew: 0}, 8407: {depth: 0, height: .72444, italic: .15486, skew: 0}, 8463: {depth: 0, height: .69444, italic: 0, skew: 0}, 8465: {depth: 0, height: .69444, italic: 0, skew: 0}, 8467: {depth: 0, height: .69444, italic: 0, skew: 0}, 8472: {depth: .19444, height: .44444, italic: 0, skew: 0}, 8476: {depth: 0, height: .69444, italic: 0, skew: 0}, 85: {depth: 0, height: .68611, italic: 0, skew: 0}, 8501: {depth: 0, height: .69444, italic: 0, skew: 0}, 8592: {depth: -.10889, height: .39111, italic: 0, skew: 0}, 8593: {depth: .19444, height: .69444, italic: 0, skew: 0}, 8594: {depth: -.10889, height: .39111, italic: 0, skew: 0}, 8595: {depth: .19444, height: .69444, italic: 0, skew: 0}, 8596: {depth: -.10889, height: .39111, italic: 0, skew: 0}, 8597: {depth: .25, height: .75, italic: 0, skew: 0}, 8598: {depth: .19444, height: .69444, italic: 0, skew: 0}, 8599: {depth: .19444, height: .69444, italic: 0, skew: 0}, 86: {depth: 0, height: .68611, italic: .01597, skew: 0}, 8600: {depth: .19444, height: .69444, italic: 0, skew: 0}, 8601: {depth: .19444, height: .69444, italic: 0, skew: 0}, 8636: {depth: -.10889, height: .39111, italic: 0, skew: 0}, 8637: {depth: -.10889, height: .39111, italic: 0, skew: 0}, 8640: {depth: -.10889, height: .39111, italic: 0, skew: 0}, 8641: {depth: -.10889, height: .39111, italic: 0, skew: 0}, 8656: {depth: -.10889, height: .39111, italic: 0, skew: 0}, 8657: {depth: .19444, height: .69444, italic: 0, skew: 0}, 8658: {depth: -.10889, height: .39111, italic: 0, skew: 0}, 8659: {depth: .19444, height: .69444, italic: 0, skew: 0}, 8660: {depth: -.10889, height: .39111, italic: 0, skew: 0}, 8661: {depth: .25, height: .75, italic: 0, skew: 0}, 87: {depth: 0, height: .68611, italic: .01597, skew: 0}, 8704: {depth: 0, height: .69444, italic: 0, skew: 0}, 8706: {depth: 0, height: .69444, italic: .06389, skew: 0}, 8707: {depth: 0, height: .69444, italic: 0, skew: 0}, 8709: {depth: .05556, height: .75, italic: 0, skew: 0}, 8711: {depth: 0, height: .68611, italic: 0, skew: 0}, 8712: {depth: .08556, height: .58556, italic: 0, skew: 0}, 8715: {depth: .08556, height: .58556, italic: 0, skew: 0}, 8722: {depth: .13333, height: .63333, italic: 0, skew: 0}, 8723: {depth: .13333, height: .63333, italic: 0, skew: 0}, 8725: {depth: .25, height: .75, italic: 0, skew: 0}, 8726: {depth: .25, height: .75, italic: 0, skew: 0}, 8727: {depth: -.02778, height: .47222, italic: 0, skew: 0}, 8728: {depth: -.02639, height: .47361, italic: 0, skew: 0}, 8729: {depth: -.02639, height: .47361, italic: 0, skew: 0}, 8730: {depth: .18, height: .82, italic: 0, skew: 0}, 8733: {depth: 0, height: .44444, italic: 0, skew: 0}, 8734: {depth: 0, height: .44444, italic: 0, skew: 0}, 8736: {depth: 0, height: .69224, italic: 0, skew: 0}, 8739: {depth: .25, height: .75, italic: 0, skew: 0}, 8741: {depth: .25, height: .75, italic: 0, skew: 0}, 8743: {depth: 0, height: .55556, italic: 0, skew: 0}, 8744: {depth: 0, height: .55556, italic: 0, skew: 0}, 8745: {depth: 0, height: .55556, italic: 0, skew: 0}, 8746: {depth: 0, height: .55556, italic: 0, skew: 0}, 8747: {depth: .19444, height: .69444, italic: .12778, skew: 0}, 8764: {depth: -.10889, height: .39111, italic: 0, skew: 0}, 8768: {depth: .19444, height: .69444, italic: 0, skew: 0}, 8771: {depth: .00222, height: .50222, italic: 0, skew: 0}, 8776: {depth: .02444, height: .52444, italic: 0, skew: 0}, 8781: {depth: .00222, height: .50222, italic: 0, skew: 0}, 88: {depth: 0, height: .68611, italic: 0, skew: 0}, 8801: {depth: .00222, height: .50222, italic: 0, skew: 0}, 8804: {depth: .19667, height: .69667, italic: 0, skew: 0}, 8805: {depth: .19667, height: .69667, italic: 0, skew: 0}, 8810: {depth: .08556, height: .58556, italic: 0, skew: 0}, 8811: {depth: .08556, height: .58556, italic: 0, skew: 0}, 8826: {depth: .08556, height: .58556, italic: 0, skew: 0}, 8827: {depth: .08556, height: .58556, italic: 0, skew: 0}, 8834: {depth: .08556, height: .58556, italic: 0, skew: 0}, 8835: {depth: .08556, height: .58556, italic: 0, skew: 0}, 8838: {depth: .19667, height: .69667, italic: 0, skew: 0}, 8839: {depth: .19667, height: .69667, italic: 0, skew: 0}, 8846: {depth: 0, height: .55556, italic: 0, skew: 0}, 8849: {depth: .19667, height: .69667, italic: 0, skew: 0}, 8850: {depth: .19667, height: .69667, italic: 0, skew: 0}, 8851: {depth: 0, height: .55556, italic: 0, skew: 0}, 8852: {depth: 0, height: .55556, italic: 0, skew: 0}, 8853: {depth: .13333, height: .63333, italic: 0, skew: 0}, 8854: {depth: .13333, height: .63333, italic: 0, skew: 0}, 8855: {depth: .13333, height: .63333, italic: 0, skew: 0}, 8856: {depth: .13333, height: .63333, italic: 0, skew: 0}, 8857: {depth: .13333, height: .63333, italic: 0, skew: 0}, 8866: {depth: 0, height: .69444, italic: 0, skew: 0}, 8867: {depth: 0, height: .69444, italic: 0, skew: 0}, 8868: {depth: 0, height: .69444, italic: 0, skew: 0}, 8869: {depth: 0, height: .69444, italic: 0, skew: 0}, 89: {depth: 0, height: .68611, italic: .02875, skew: 0}, 8900: {depth: -.02639, height: .47361, italic: 0, skew: 0}, 8901: {depth: -.02639, height: .47361, italic: 0, skew: 0}, 8902: {depth: -.02778, height: .47222, italic: 0, skew: 0}, 8968: {depth: .25, height: .75, italic: 0, skew: 0}, 8969: {depth: .25, height: .75, italic: 0, skew: 0}, 8970: {depth: .25, height: .75, italic: 0, skew: 0}, 8971: {depth: .25, height: .75, italic: 0, skew: 0}, 8994: {depth: -.13889, height: .36111, italic: 0, skew: 0}, 8995: {depth: -.13889, height: .36111, italic: 0, skew: 0}, 90: {depth: 0, height: .68611, italic: 0, skew: 0}, 91: {depth: .25, height: .75, italic: 0, skew: 0}, 915: {depth: 0, height: .68611, italic: 0, skew: 0}, 916: {depth: 0, height: .68611, italic: 0, skew: 0}, 92: {depth: .25, height: .75, italic: 0, skew: 0}, 920: {depth: 0, height: .68611, italic: 0, skew: 0}, 923: {depth: 0, height: .68611, italic: 0, skew: 0}, 926: {depth: 0, height: .68611, italic: 0, skew: 0}, 928: {depth: 0, height: .68611, italic: 0, skew: 0}, 93: {depth: .25, height: .75, italic: 0, skew: 0}, 931: {depth: 0, height: .68611, italic: 0, skew: 0}, 933: {depth: 0, height: .68611, italic: 0, skew: 0}, 934: {depth: 0, height: .68611, italic: 0, skew: 0}, 936: {depth: 0, height: .68611, italic: 0, skew: 0}, 937: {depth: 0, height: .68611, italic: 0, skew: 0}, 94: {depth: 0, height: .69444, italic: 0, skew: 0}, 95: {depth: .31, height: .13444, italic: .03194, skew: 0}, 96: {depth: 0, height: .69444, italic: 0, skew: 0}, 9651: {depth: .19444, height: .69444, italic: 0, skew: 0}, 9657: {depth: -.02778, height: .47222, italic: 0, skew: 0}, 9661: {depth: .19444, height: .69444, italic: 0, skew: 0}, 9667: {depth: -.02778, height: .47222, italic: 0, skew: 0}, 97: {depth: 0, height: .44444, italic: 0, skew: 0}, 9711: {depth: .19444, height: .69444, italic: 0, skew: 0}, 98: {depth: 0, height: .69444, italic: 0, skew: 0}, 9824: {depth: .12963, height: .69444, italic: 0, skew: 0}, 9825: {depth: .12963, height: .69444, italic: 0, skew: 0}, 9826: {depth: .12963, height: .69444, italic: 0, skew: 0}, 9827: {depth: .12963, height: .69444, italic: 0, skew: 0}, 9837: {depth: 0, height: .75, italic: 0, skew: 0}, 9838: {depth: .19444, height: .69444, italic: 0, skew: 0}, 9839: {depth: .19444, height: .69444, italic: 0, skew: 0}, 99: {depth: 0, height: .44444, italic: 0, skew: 0}}, "Main-Italic": {100: {depth: 0, height: .69444, italic: .10333, skew: 0}, 101: {depth: 0, height: .43056, italic: .07514, skew: 0}, 102: {depth: .19444, height: .69444, italic: .21194, skew: 0}, 103: {depth: .19444, height: .43056, italic: .08847, skew: 0}, 104: {depth: 0, height: .69444, italic: .07671, skew: 0}, 105: {depth: 0, height: .65536, italic: .1019, skew: 0}, 106: {depth: .19444, height: .65536, italic: .14467, skew: 0}, 107: {depth: 0, height: .69444, italic: .10764, skew: 0}, 108: {depth: 0, height: .69444, italic: .10333, skew: 0}, 109: {depth: 0, height: .43056, italic: .07671, skew: 0}, 110: {depth: 0, height: .43056, italic: .07671, skew: 0}, 111: {depth: 0, height: .43056, italic: .06312, skew: 0}, 112: {depth: .19444, height: .43056, italic: .06312, skew: 0}, 113: {depth: .19444, height: .43056, italic: .08847, skew: 0}, 114: {depth: 0, height: .43056, italic: .10764, skew: 0}, 115: {depth: 0, height: .43056, italic: .08208, skew: 0}, 116: {depth: 0, height: .61508, italic: .09486, skew: 0}, 117: {depth: 0, height: .43056, italic: .07671, skew: 0}, 118: {depth: 0, height: .43056, italic: .10764, skew: 0}, 119: {depth: 0, height: .43056, italic: .10764, skew: 0}, 120: {depth: 0, height: .43056, italic: .12042, skew: 0}, 121: {depth: .19444, height: .43056, italic: .08847, skew: 0}, 122: {depth: 0, height: .43056, italic: .12292, skew: 0}, 126: {depth: .35, height: .31786, italic: .11585, skew: 0}, 163: {depth: 0, height: .69444, italic: 0, skew: 0}, 305: {depth: 0, height: .43056, italic: .07671, skew: 0}, 33: {depth: 0, height: .69444, italic: .12417, skew: 0}, 34: {depth: 0, height: .69444, italic: .06961, skew: 0}, 35: {depth: .19444, height: .69444, italic: .06616, skew: 0}, 37: {depth: .05556, height: .75, italic: .13639, skew: 0}, 38: {depth: 0, height: .69444, italic: .09694, skew: 0}, 39: {depth: 0, height: .69444, italic: .12417, skew: 0}, 40: {depth: .25, height: .75, italic: .16194, skew: 0}, 41: {depth: .25, height: .75, italic: .03694, skew: 0}, 42: {depth: 0, height: .75, italic: .14917, skew: 0}, 43: {depth: .05667, height: .56167, italic: .03694, skew: 0}, 44: {depth: .19444, height: .10556, italic: 0, skew: 0}, 45: {depth: 0, height: .43056, italic: .02826, skew: 0}, 46: {depth: 0, height: .10556, italic: 0, skew: 0}, 47: {depth: .25, height: .75, italic: .16194, skew: 0}, 48: {depth: 0, height: .64444, italic: .13556, skew: 0}, 49: {depth: 0, height: .64444, italic: .13556, skew: 0}, 50: {depth: 0, height: .64444, italic: .13556, skew: 0}, 51: {depth: 0, height: .64444, italic: .13556, skew: 0}, 52: {depth: .19444, height: .64444, italic: .13556, skew: 0}, 53: {depth: 0, height: .64444, italic: .13556, skew: 0}, 54: {depth: 0, height: .64444, italic: .13556, skew: 0}, 55: {depth: .19444, height: .64444, italic: .13556, skew: 0}, 56: {depth: 0, height: .64444, italic: .13556, skew: 0}, 567: {depth: .19444, height: .43056, italic: .03736, skew: 0}, 57: {depth: 0, height: .64444, italic: .13556, skew: 0}, 58: {depth: 0, height: .43056, italic: .0582, skew: 0}, 59: {depth: .19444, height: .43056, italic: .0582, skew: 0}, 61: {depth: -.13313, height: .36687, italic: .06616, skew: 0}, 63: {depth: 0, height: .69444, italic: .1225, skew: 0}, 64: {depth: 0, height: .69444, italic: .09597, skew: 0}, 65: {depth: 0, height: .68333, italic: 0, skew: 0}, 66: {depth: 0, height: .68333, italic: .10257, skew: 0}, 67: {depth: 0, height: .68333, italic: .14528, skew: 0}, 68: {depth: 0, height: .68333, italic: .09403, skew: 0}, 69: {depth: 0, height: .68333, italic: .12028, skew: 0}, 70: {depth: 0, height: .68333, italic: .13305, skew: 0}, 71: {depth: 0, height: .68333, italic: .08722, skew: 0}, 72: {depth: 0, height: .68333, italic: .16389, skew: 0}, 73: {depth: 0, height: .68333, italic: .15806, skew: 0}, 74: {depth: 0, height: .68333, italic: .14028, skew: 0}, 75: {depth: 0, height: .68333, italic: .14528, skew: 0}, 76: {depth: 0, height: .68333, italic: 0, skew: 0}, 768: {depth: 0, height: .69444, italic: 0, skew: 0}, 769: {depth: 0, height: .69444, italic: .09694, skew: 0}, 77: {depth: 0, height: .68333, italic: .16389, skew: 0}, 770: {depth: 0, height: .69444, italic: .06646, skew: 0}, 771: {depth: 0, height: .66786, italic: .11585, skew: 0}, 772: {depth: 0, height: .56167, italic: .10333, skew: 0}, 774: {depth: 0, height: .69444, italic: .10806, skew: 0}, 775: {depth: 0, height: .66786, italic: .11752, skew: 0}, 776: {depth: 0, height: .66786, italic: .10474, skew: 0}, 778: {depth: 0, height: .69444, italic: 0, skew: 0}, 779: {depth: 0, height: .69444, italic: .1225, skew: 0}, 78: {depth: 0, height: .68333, italic: .16389, skew: 0}, 780: {depth: 0, height: .62847, italic: .08295, skew: 0}, 79: {depth: 0, height: .68333, italic: .09403, skew: 0}, 80: {depth: 0, height: .68333, italic: .10257, skew: 0}, 81: {depth: .19444, height: .68333, italic: .09403, skew: 0}, 82: {depth: 0, height: .68333, italic: .03868, skew: 0}, 8211: {depth: 0, height: .43056, italic: .09208, skew: 0}, 8212: {depth: 0, height: .43056, italic: .09208, skew: 0}, 8216: {depth: 0, height: .69444, italic: .12417, skew: 0}, 8217: {depth: 0, height: .69444, italic: .12417, skew: 0}, 8220: {depth: 0, height: .69444, italic: .1685, skew: 0}, 8221: {depth: 0, height: .69444, italic: .06961, skew: 0}, 83: {depth: 0, height: .68333, italic: .11972, skew: 0}, 84: {depth: 0, height: .68333, italic: .13305, skew: 0}, 8463: {depth: 0, height: .68889, italic: 0, skew: 0}, 85: {depth: 0, height: .68333, italic: .16389, skew: 0}, 86: {depth: 0, height: .68333, italic: .18361, skew: 0}, 87: {depth: 0, height: .68333, italic: .18361, skew: 0}, 88: {depth: 0, height: .68333, italic: .15806, skew: 0}, 89: {depth: 0, height: .68333, italic: .19383, skew: 0}, 90: {depth: 0, height: .68333, italic: .14528, skew: 0}, 91: {depth: .25, height: .75, italic: .1875, skew: 0}, 915: {depth: 0, height: .68333, italic: .13305, skew: 0}, 916: {depth: 0, height: .68333, italic: 0, skew: 0}, 920: {depth: 0, height: .68333, italic: .09403, skew: 0}, 923: {depth: 0, height: .68333, italic: 0, skew: 0}, 926: {depth: 0, height: .68333, italic: .15294, skew: 0}, 928: {depth: 0, height: .68333, italic: .16389, skew: 0}, 93: {depth: .25, height: .75, italic: .10528, skew: 0}, 931: {depth: 0, height: .68333, italic: .12028, skew: 0}, 933: {depth: 0, height: .68333, italic: .11111, skew: 0}, 934: {depth: 0, height: .68333, italic: .05986, skew: 0}, 936: {depth: 0, height: .68333, italic: .11111, skew: 0}, 937: {depth: 0, height: .68333, italic: .10257, skew: 0}, 94: {depth: 0, height: .69444, italic: .06646, skew: 0}, 95: {depth: .31, height: .12056, italic: .09208, skew: 0}, 97: {depth: 0, height: .43056, italic: .07671, skew: 0}, 98: {depth: 0, height: .69444, italic: .06312, skew: 0}, 99: {depth: 0, height: .43056, italic: .05653, skew: 0}}, "Main-Regular": {32: {depth: -0, height: 0, italic: 0, skew: 0}, 160: {depth: -0, height: 0, italic: 0, skew: 0}, 8230: {depth: -0, height: .12, italic: 0, skew: 0}, 8773: {depth: -.022, height: .589, italic: 0, skew: 0}, 8800: {depth: .215, height: .716, italic: 0, skew: 0}, 8942: {depth: .03, height: .9, italic: 0, skew: 0}, 8943: {depth: -.19, height: .31, italic: 0, skew: 0}, 8945: {depth: -.1, height: .82, italic: 0, skew: 0}, 100: {depth: 0, height: .69444, italic: 0, skew: 0}, 101: {depth: 0, height: .43056, italic: 0, skew: 0}, 102: {depth: 0, height: .69444, italic: .07778, skew: 0}, 10216: {depth: .25, height: .75, italic: 0, skew: 0}, 10217: {depth: .25, height: .75, italic: 0, skew: 0}, 103: {depth: .19444, height: .43056, italic: .01389, skew: 0}, 104: {depth: 0, height: .69444, italic: 0, skew: 0}, 105: {depth: 0, height: .66786, italic: 0, skew: 0}, 106: {depth: .19444, height: .66786, italic: 0, skew: 0}, 107: {depth: 0, height: .69444, italic: 0, skew: 0}, 108: {depth: 0, height: .69444, italic: 0, skew: 0}, 10815: {depth: 0, height: .68333, italic: 0, skew: 0}, 109: {depth: 0, height: .43056, italic: 0, skew: 0}, 10927: {depth: .13597, height: .63597, italic: 0, skew: 0}, 10928: {depth: .13597, height: .63597, italic: 0, skew: 0}, 110: {depth: 0, height: .43056, italic: 0, skew: 0}, 111: {depth: 0, height: .43056, italic: 0, skew: 0}, 112: {depth: .19444, height: .43056, italic: 0, skew: 0}, 113: {depth: .19444, height: .43056, italic: 0, skew: 0}, 114: {depth: 0, height: .43056, italic: 0, skew: 0}, 115: {depth: 0, height: .43056, italic: 0, skew: 0}, 116: {depth: 0, height: .61508, italic: 0, skew: 0}, 117: {depth: 0, height: .43056, italic: 0, skew: 0}, 118: {depth: 0, height: .43056, italic: .01389, skew: 0}, 119: {depth: 0, height: .43056, italic: .01389, skew: 0}, 120: {depth: 0, height: .43056, italic: 0, skew: 0}, 121: {depth: .19444, height: .43056, italic: .01389, skew: 0}, 122: {depth: 0, height: .43056, italic: 0, skew: 0}, 123: {depth: .25, height: .75, italic: 0, skew: 0}, 124: {depth: .25, height: .75, italic: 0, skew: 0}, 125: {depth: .25, height: .75, italic: 0, skew: 0}, 126: {depth: .35, height: .31786, italic: 0, skew: 0}, 168: {depth: 0, height: .66786, italic: 0, skew: 0}, 172: {depth: 0, height: .43056, italic: 0, skew: 0}, 175: {depth: 0, height: .56778, italic: 0, skew: 0}, 176: {depth: 0, height: .69444, italic: 0, skew: 0}, 177: {depth: .08333, height: .58333, italic: 0, skew: 0}, 180: {depth: 0, height: .69444, italic: 0, skew: 0}, 215: {depth: .08333, height: .58333, italic: 0, skew: 0}, 247: {depth: .08333, height: .58333, italic: 0, skew: 0}, 305: {depth: 0, height: .43056, italic: 0, skew: 0}, 33: {depth: 0, height: .69444, italic: 0, skew: 0}, 34: {depth: 0, height: .69444, italic: 0, skew: 0}, 35: {depth: .19444, height: .69444, italic: 0, skew: 0}, 36: {depth: .05556, height: .75, italic: 0, skew: 0}, 37: {depth: .05556, height: .75, italic: 0, skew: 0}, 38: {depth: 0, height: .69444, italic: 0, skew: 0}, 39: {depth: 0, height: .69444, italic: 0, skew: 0}, 40: {depth: .25, height: .75, italic: 0, skew: 0}, 41: {depth: .25, height: .75, italic: 0, skew: 0}, 42: {depth: 0, height: .75, italic: 0, skew: 0}, 43: {depth: .08333, height: .58333, italic: 0, skew: 0}, 44: {depth: .19444, height: .10556, italic: 0, skew: 0}, 45: {depth: 0, height: .43056, italic: 0, skew: 0}, 46: {depth: 0, height: .10556, italic: 0, skew: 0}, 47: {depth: .25, height: .75, italic: 0, skew: 0}, 48: {depth: 0, height: .64444, italic: 0, skew: 0}, 49: {depth: 0, height: .64444, italic: 0, skew: 0}, 50: {depth: 0, height: .64444, italic: 0, skew: 0}, 51: {depth: 0, height: .64444, italic: 0, skew: 0}, 52: {depth: 0, height: .64444, italic: 0, skew: 0}, 53: {depth: 0, height: .64444, italic: 0, skew: 0}, 54: {depth: 0, height: .64444, italic: 0, skew: 0}, 55: {depth: 0, height: .64444, italic: 0, skew: 0}, 56: {depth: 0, height: .64444, italic: 0, skew: 0}, 567: {depth: .19444, height: .43056, italic: 0, skew: 0}, 57: {depth: 0, height: .64444, italic: 0, skew: 0}, 58: {depth: 0, height: .43056, italic: 0, skew: 0}, 59: {depth: .19444, height: .43056, italic: 0, skew: 0}, 60: {depth: .0391, height: .5391, italic: 0, skew: 0}, 61: {depth: -.13313, height: .36687, italic: 0, skew: 0}, 62: {depth: .0391, height: .5391, italic: 0, skew: 0}, 63: {depth: 0, height: .69444, italic: 0, skew: 0}, 64: {depth: 0, height: .69444, italic: 0, skew: 0}, 65: {depth: 0, height: .68333, italic: 0, skew: 0}, 66: {depth: 0, height: .68333, italic: 0, skew: 0}, 67: {depth: 0, height: .68333, italic: 0, skew: 0}, 68: {depth: 0, height: .68333, italic: 0, skew: 0}, 69: {depth: 0, height: .68333, italic: 0, skew: 0}, 70: {depth: 0, height: .68333, italic: 0, skew: 0}, 71: {depth: 0, height: .68333, italic: 0, skew: 0}, 710: {depth: 0, height: .69444, italic: 0, skew: 0}, 711: {depth: 0, height: .62847, italic: 0, skew: 0}, 713: {depth: 0, height: .56778, italic: 0, skew: 0}, 714: {depth: 0, height: .69444, italic: 0, skew: 0}, 715: {depth: 0, height: .69444, italic: 0, skew: 0}, 72: {depth: 0, height: .68333, italic: 0, skew: 0}, 728: {depth: 0, height: .69444, italic: 0, skew: 0}, 729: {depth: 0, height: .66786, italic: 0, skew: 0}, 73: {depth: 0, height: .68333, italic: 0, skew: 0}, 730: {depth: 0, height: .69444, italic: 0, skew: 0}, 732: {depth: 0, height: .66786, italic: 0, skew: 0}, 74: {depth: 0, height: .68333, italic: 0, skew: 0}, 75: {depth: 0, height: .68333, italic: 0, skew: 0}, 76: {depth: 0, height: .68333, italic: 0, skew: 0}, 768: {depth: 0, height: .69444, italic: 0, skew: 0}, 769: {depth: 0, height: .69444, italic: 0, skew: 0}, 77: {depth: 0, height: .68333, italic: 0, skew: 0}, 770: {depth: 0, height: .69444, italic: 0, skew: 0}, 771: {depth: 0, height: .66786, italic: 0, skew: 0}, 772: {depth: 0, height: .56778, italic: 0, skew: 0}, 774: {depth: 0, height: .69444, italic: 0, skew: 0}, 775: {depth: 0, height: .66786, italic: 0, skew: 0}, 776: {depth: 0, height: .66786, italic: 0, skew: 0}, 778: {depth: 0, height: .69444, italic: 0, skew: 0}, 779: {depth: 0, height: .69444, italic: 0, skew: 0}, 78: {depth: 0, height: .68333, italic: 0, skew: 0}, 780: {depth: 0, height: .62847, italic: 0, skew: 0}, 79: {depth: 0, height: .68333, italic: 0, skew: 0}, 80: {depth: 0, height: .68333, italic: 0, skew: 0}, 81: {depth: .19444, height: .68333, italic: 0, skew: 0}, 82: {depth: 0, height: .68333, italic: 0, skew: 0}, 8211: {depth: 0, height: .43056, italic: .02778, skew: 0}, 8212: {depth: 0, height: .43056, italic: .02778, skew: 0}, 8216: {depth: 0, height: .69444, italic: 0, skew: 0}, 8217: {depth: 0, height: .69444, italic: 0, skew: 0}, 8220: {depth: 0, height: .69444, italic: 0, skew: 0}, 8221: {depth: 0, height: .69444, italic: 0, skew: 0}, 8224: {depth: .19444, height: .69444, italic: 0, skew: 0}, 8225: {depth: .19444, height: .69444, italic: 0, skew: 0}, 824: {depth: .19444, height: .69444, italic: 0, skew: 0}, 8242: {depth: 0, height: .55556, italic: 0, skew: 0}, 83: {depth: 0, height: .68333, italic: 0, skew: 0}, 84: {depth: 0, height: .68333, italic: 0, skew: 0}, 8407: {depth: 0, height: .71444, italic: .15382, skew: 0}, 8463: {depth: 0, height: .68889, italic: 0, skew: 0}, 8465: {depth: 0, height: .69444, italic: 0, skew: 0}, 8467: {depth: 0, height: .69444, italic: 0, skew: .11111}, 8472: {depth: .19444, height: .43056, italic: 0, skew: .11111}, 8476: {depth: 0, height: .69444, italic: 0, skew: 0}, 85: {depth: 0, height: .68333, italic: 0, skew: 0}, 8501: {depth: 0, height: .69444, italic: 0, skew: 0}, 8592: {depth: -.13313, height: .36687, italic: 0, skew: 0}, 8593: {depth: .19444, height: .69444, italic: 0, skew: 0}, 8594: {depth: -.13313, height: .36687, italic: 0, skew: 0}, 8595: {depth: .19444, height: .69444, italic: 0, skew: 0}, 8596: {depth: -.13313, height: .36687, italic: 0, skew: 0}, 8597: {depth: .25, height: .75, italic: 0, skew: 0}, 8598: {depth: .19444, height: .69444, italic: 0, skew: 0}, 8599: {depth: .19444, height: .69444, italic: 0, skew: 0}, 86: {depth: 0, height: .68333, italic: .01389, skew: 0}, 8600: {depth: .19444, height: .69444, italic: 0, skew: 0}, 8601: {depth: .19444, height: .69444, italic: 0, skew: 0}, 8636: {depth: -.13313, height: .36687, italic: 0, skew: 0}, 8637: {depth: -.13313, height: .36687, italic: 0, skew: 0}, 8640: {depth: -.13313, height: .36687, italic: 0, skew: 0}, 8641: {depth: -.13313, height: .36687, italic: 0, skew: 0}, 8656: {depth: -.13313, height: .36687, italic: 0, skew: 0}, 8657: {depth: .19444, height: .69444, italic: 0, skew: 0}, 8658: {depth: -.13313, height: .36687, italic: 0, skew: 0}, 8659: {depth: .19444, height: .69444, italic: 0, skew: 0}, 8660: {depth: -.13313, height: .36687, italic: 0, skew: 0}, 8661: {depth: .25, height: .75, italic: 0, skew: 0}, 87: {depth: 0, height: .68333, italic: .01389, skew: 0}, 8704: {depth: 0, height: .69444, italic: 0, skew: 0}, 8706: {depth: 0, height: .69444, italic: .05556, skew: .08334}, 8707: {depth: 0, height: .69444, italic: 0, skew: 0}, 8709: {depth: .05556, height: .75, italic: 0, skew: 0}, 8711: {depth: 0, height: .68333, italic: 0, skew: 0}, 8712: {depth: .0391, height: .5391, italic: 0, skew: 0}, 8715: {depth: .0391, height: .5391, italic: 0, skew: 0}, 8722: {depth: .08333, height: .58333, italic: 0, skew: 0}, 8723: {depth: .08333, height: .58333, italic: 0, skew: 0}, 8725: {depth: .25, height: .75, italic: 0, skew: 0}, 8726: {depth: .25, height: .75, italic: 0, skew: 0}, 8727: {depth: -.03472, height: .46528, italic: 0, skew: 0}, 8728: {depth: -.05555, height: .44445, italic: 0, skew: 0}, 8729: {depth: -.05555, height: .44445, italic: 0, skew: 0}, 8730: {depth: .2, height: .8, italic: 0, skew: 0}, 8733: {depth: 0, height: .43056, italic: 0, skew: 0}, 8734: {depth: 0, height: .43056, italic: 0, skew: 0}, 8736: {depth: 0, height: .69224, italic: 0, skew: 0}, 8739: {depth: .25, height: .75, italic: 0, skew: 0}, 8741: {depth: .25, height: .75, italic: 0, skew: 0}, 8743: {depth: 0, height: .55556, italic: 0, skew: 0}, 8744: {depth: 0, height: .55556, italic: 0, skew: 0}, 8745: {depth: 0, height: .55556, italic: 0, skew: 0}, 8746: {depth: 0, height: .55556, italic: 0, skew: 0}, 8747: {depth: .19444, height: .69444, italic: .11111, skew: 0}, 8764: {depth: -.13313, height: .36687, italic: 0, skew: 0}, 8768: {depth: .19444, height: .69444, italic: 0, skew: 0}, 8771: {depth: -.03625, height: .46375, italic: 0, skew: 0}, 8776: {depth: -.01688, height: .48312, italic: 0, skew: 0}, 8781: {depth: -.03625, height: .46375, italic: 0, skew: 0}, 88: {depth: 0, height: .68333, italic: 0, skew: 0}, 8801: {depth: -.03625, height: .46375, italic: 0, skew: 0}, 8804: {depth: .13597, height: .63597, italic: 0, skew: 0}, 8805: {depth: .13597, height: .63597, italic: 0, skew: 0}, 8810: {depth: .0391, height: .5391, italic: 0, skew: 0}, 8811: {depth: .0391, height: .5391, italic: 0, skew: 0}, 8826: {depth: .0391, height: .5391, italic: 0, skew: 0}, 8827: {depth: .0391, height: .5391, italic: 0, skew: 0}, 8834: {depth: .0391, height: .5391, italic: 0, skew: 0}, 8835: {depth: .0391, height: .5391, italic: 0, skew: 0}, 8838: {depth: .13597, height: .63597, italic: 0, skew: 0}, 8839: {depth: .13597, height: .63597, italic: 0, skew: 0}, 8846: {depth: 0, height: .55556, italic: 0, skew: 0}, 8849: {depth: .13597, height: .63597, italic: 0, skew: 0}, 8850: {depth: .13597, height: .63597, italic: 0, skew: 0}, 8851: {depth: 0, height: .55556, italic: 0, skew: 0}, 8852: {depth: 0, height: .55556, italic: 0, skew: 0}, 8853: {depth: .08333, height: .58333, italic: 0, skew: 0}, 8854: {depth: .08333, height: .58333, italic: 0, skew: 0}, 8855: {depth: .08333, height: .58333, italic: 0, skew: 0}, 8856: {depth: .08333, height: .58333, italic: 0, skew: 0}, 8857: {depth: .08333, height: .58333, italic: 0, skew: 0}, 8866: {depth: 0, height: .69444, italic: 0, skew: 0}, 8867: {depth: 0, height: .69444, italic: 0, skew: 0}, 8868: {depth: 0, height: .69444, italic: 0, skew: 0}, 8869: {depth: 0, height: .69444, italic: 0, skew: 0}, 89: {depth: 0, height: .68333, italic: .025, skew: 0}, 8900: {depth: -.05555, height: .44445, italic: 0, skew: 0}, 8901: {depth: -.05555, height: .44445, italic: 0, skew: 0}, 8902: {depth: -.03472, height: .46528, italic: 0, skew: 0}, 8968: {depth: .25, height: .75, italic: 0, skew: 0}, 8969: {depth: .25, height: .75, italic: 0, skew: 0}, 8970: {depth: .25, height: .75, italic: 0, skew: 0}, 8971: {depth: .25, height: .75, italic: 0, skew: 0}, 8994: {depth: -.14236, height: .35764, italic: 0, skew: 0}, 8995: {depth: -.14236, height: .35764, italic: 0, skew: 0}, 90: {depth: 0, height: .68333, italic: 0, skew: 0}, 91: {depth: .25, height: .75, italic: 0, skew: 0}, 915: {depth: 0, height: .68333, italic: 0, skew: 0}, 916: {depth: 0, height: .68333, italic: 0, skew: 0}, 92: {depth: .25, height: .75, italic: 0, skew: 0}, 920: {depth: 0, height: .68333, italic: 0, skew: 0}, 923: {depth: 0, height: .68333, italic: 0, skew: 0}, 926: {depth: 0, height: .68333, italic: 0, skew: 0}, 928: {depth: 0, height: .68333, italic: 0, skew: 0}, 93: {depth: .25, height: .75, italic: 0, skew: 0}, 931: {depth: 0, height: .68333, italic: 0, skew: 0}, 933: {depth: 0, height: .68333, italic: 0, skew: 0}, 934: {depth: 0, height: .68333, italic: 0, skew: 0}, 936: {depth: 0, height: .68333, italic: 0, skew: 0}, 937: {depth: 0, height: .68333, italic: 0, skew: 0}, 94: {depth: 0, height: .69444, italic: 0, skew: 0}, 95: {depth: .31, height: .12056, italic: .02778, skew: 0}, 96: {depth: 0, height: .69444, italic: 0, skew: 0}, 9651: {depth: .19444, height: .69444, italic: 0, skew: 0}, 9657: {depth: -.03472, height: .46528, italic: 0, skew: 0}, 9661: {depth: .19444, height: .69444, italic: 0, skew: 0}, 9667: {depth: -.03472, height: .46528, italic: 0, skew: 0}, 97: {depth: 0, height: .43056, italic: 0, skew: 0}, 9711: {depth: .19444, height: .69444, italic: 0, skew: 0}, 98: {depth: 0, height: .69444, italic: 0, skew: 0}, 9824: {depth: .12963, height: .69444, italic: 0, skew: 0}, 9825: {depth: .12963, height: .69444, italic: 0, skew: 0}, 9826: {depth: .12963, height: .69444, italic: 0, skew: 0}, 9827: {depth: .12963, height: .69444, italic: 0, skew: 0}, 9837: {depth: 0, height: .75, italic: 0, skew: 0}, 9838: {depth: .19444, height: .69444, italic: 0, skew: 0}, 9839: {depth: .19444, height: .69444, italic: 0, skew: 0}, 99: {depth: 0, height: .43056, italic: 0, skew: 0}}, "Math-BoldItalic": {100: {depth: 0, height: .69444, italic: 0, skew: 0}, 1009: {depth: .19444, height: .44444, italic: 0, skew: 0}, 101: {depth: 0, height: .44444, italic: 0, skew: 0}, 1013: {depth: 0, height: .44444, italic: 0, skew: 0}, 102: {depth: .19444, height: .69444, italic: .11042, skew: 0}, 103: {depth: .19444, height: .44444, italic: .03704, skew: 0}, 104: {depth: 0, height: .69444, italic: 0, skew: 0}, 105: {depth: 0, height: .69326, italic: 0, skew: 0}, 106: {depth: .19444, height: .69326, italic: .0622, skew: 0}, 107: {depth: 0, height: .69444, italic: .01852, skew: 0}, 108: {depth: 0, height: .69444, italic: .0088, skew: 0}, 109: {depth: 0, height: .44444, italic: 0, skew: 0}, 110: {depth: 0, height: .44444, italic: 0, skew: 0}, 111: {depth: 0, height: .44444, italic: 0, skew: 0}, 112: {depth: .19444, height: .44444, italic: 0, skew: 0}, 113: {depth: .19444, height: .44444, italic: .03704, skew: 0}, 114: {depth: 0, height: .44444, italic: .03194, skew: 0}, 115: {depth: 0, height: .44444, italic: 0, skew: 0}, 116: {depth: 0, height: .63492, italic: 0, skew: 0}, 117: {depth: 0, height: .44444, italic: 0, skew: 0}, 118: {depth: 0, height: .44444, italic: .03704, skew: 0}, 119: {depth: 0, height: .44444, italic: .02778, skew: 0}, 120: {depth: 0, height: .44444, italic: 0, skew: 0}, 121: {depth: .19444, height: .44444, italic: .03704, skew: 0}, 122: {depth: 0, height: .44444, italic: .04213, skew: 0}, 47: {depth: .19444, height: .69444, italic: 0, skew: 0}, 65: {depth: 0, height: .68611, italic: 0, skew: 0}, 66: {depth: 0, height: .68611, italic: .04835, skew: 0}, 67: {depth: 0, height: .68611, italic: .06979, skew: 0}, 68: {depth: 0, height: .68611, italic: .03194, skew: 0}, 69: {depth: 0, height: .68611, italic: .05451, skew: 0}, 70: {depth: 0, height: .68611, italic: .15972, skew: 0}, 71: {depth: 0, height: .68611, italic: 0, skew: 0}, 72: {depth: 0, height: .68611, italic: .08229, skew: 0}, 73: {depth: 0, height: .68611, italic: .07778, skew: 0}, 74: {depth: 0, height: .68611, italic: .10069, skew: 0}, 75: {depth: 0, height: .68611, italic: .06979, skew: 0}, 76: {depth: 0, height: .68611, italic: 0, skew: 0}, 77: {depth: 0, height: .68611, italic: .11424, skew: 0}, 78: {depth: 0, height: .68611, italic: .11424, skew: 0}, 79: {depth: 0, height: .68611, italic: .03194, skew: 0}, 80: {depth: 0, height: .68611, italic: .15972, skew: 0}, 81: {depth: .19444, height: .68611, italic: 0, skew: 0}, 82: {depth: 0, height: .68611, italic: .00421, skew: 0}, 83: {depth: 0, height: .68611, italic: .05382, skew: 0}, 84: {depth: 0, height: .68611, italic: .15972, skew: 0}, 85: {depth: 0, height: .68611, italic: .11424, skew: 0}, 86: {depth: 0, height: .68611, italic: .25555, skew: 0}, 87: {depth: 0, height: .68611, italic: .15972, skew: 0}, 88: {depth: 0, height: .68611, italic: .07778, skew: 0}, 89: {depth: 0, height: .68611, italic: .25555, skew: 0}, 90: {depth: 0, height: .68611, italic: .06979, skew: 0}, 915: {depth: 0, height: .68611, italic: .15972, skew: 0}, 916: {depth: 0, height: .68611, italic: 0, skew: 0}, 920: {depth: 0, height: .68611, italic: .03194, skew: 0}, 923: {depth: 0, height: .68611, italic: 0, skew: 0}, 926: {depth: 0, height: .68611, italic: .07458, skew: 0}, 928: {depth: 0, height: .68611, italic: .08229, skew: 0}, 931: {depth: 0, height: .68611, italic: .05451, skew: 0}, 933: {depth: 0, height: .68611, italic: .15972, skew: 0}, 934: {depth: 0, height: .68611, italic: 0, skew: 0}, 936: {depth: 0, height: .68611, italic: .11653, skew: 0}, 937: {depth: 0, height: .68611, italic: .04835, skew: 0}, 945: {depth: 0, height: .44444, italic: 0, skew: 0}, 946: {depth: .19444, height: .69444, italic: .03403, skew: 0}, 947: {depth: .19444, height: .44444, italic: .06389, skew: 0}, 948: {depth: 0, height: .69444, italic: .03819, skew: 0}, 949: {depth: 0, height: .44444, italic: 0, skew: 0}, 950: {depth: .19444, height: .69444, italic: .06215, skew: 0}, 951: {depth: .19444, height: .44444, italic: .03704, skew: 0}, 952: {depth: 0, height: .69444, italic: .03194, skew: 0}, 953: {depth: 0, height: .44444, italic: 0, skew: 0}, 954: {depth: 0, height: .44444, italic: 0, skew: 0}, 955: {depth: 0, height: .69444, italic: 0, skew: 0}, 956: {depth: .19444, height: .44444, italic: 0, skew: 0}, 957: {depth: 0, height: .44444, italic: .06898, skew: 0}, 958: {depth: .19444, height: .69444, italic: .03021, skew: 0}, 959: {depth: 0, height: .44444, italic: 0, skew: 0}, 960: {depth: 0, height: .44444, italic: .03704, skew: 0}, 961: {depth: .19444, height: .44444, italic: 0, skew: 0}, 962: {depth: .09722, height: .44444, italic: .07917, skew: 0}, 963: {depth: 0, height: .44444, italic: .03704, skew: 0}, 964: {depth: 0, height: .44444, italic: .13472, skew: 0}, 965: {depth: 0, height: .44444, italic: .03704, skew: 0}, 966: {depth: .19444, height: .44444, italic: 0, skew: 0}, 967: {depth: .19444, height: .44444, italic: 0, skew: 0}, 968: {depth: .19444, height: .69444, italic: .03704, skew: 0}, 969: {depth: 0, height: .44444, italic: .03704, skew: 0}, 97: {depth: 0, height: .44444, italic: 0, skew: 0}, 977: {depth: 0, height: .69444, italic: 0, skew: 0}, 98: {depth: 0, height: .69444, italic: 0, skew: 0}, 981: {depth: .19444, height: .69444, italic: 0, skew: 0}, 982: {depth: 0, height: .44444, italic: .03194, skew: 0}, 99: {depth: 0, height: .44444, italic: 0, skew: 0}}, "Math-Italic": {100: {depth: 0, height: .69444, italic: 0, skew: .16667}, 1009: {depth: .19444, height: .43056, italic: 0, skew: .08334}, 101: {depth: 0, height: .43056, italic: 0, skew: .05556}, 1013: {depth: 0, height: .43056, italic: 0, skew: .05556}, 102: {depth: .19444, height: .69444, italic: .10764, skew: .16667}, 103: {depth: .19444, height: .43056, italic: .03588, skew: .02778}, 104: {depth: 0, height: .69444, italic: 0, skew: 0}, 105: {depth: 0, height: .65952, italic: 0, skew: 0}, 106: {depth: .19444, height: .65952, italic: .05724, skew: 0}, 107: {depth: 0, height: .69444, italic: .03148, skew: 0}, 108: {depth: 0, height: .69444, italic: .01968, skew: .08334}, 109: {depth: 0, height: .43056, italic: 0, skew: 0}, 110: {depth: 0, height: .43056, italic: 0, skew: 0}, 111: {depth: 0, height: .43056, italic: 0, skew: .05556}, 112: {depth: .19444, height: .43056, italic: 0, skew: .08334}, 113: {depth: .19444, height: .43056, italic: .03588, skew: .08334}, 114: {depth: 0, height: .43056, italic: .02778, skew: .05556}, 115: {depth: 0, height: .43056, italic: 0, skew: .05556}, 116: {depth: 0, height: .61508, italic: 0, skew: .08334}, 117: {depth: 0, height: .43056, italic: 0, skew: .02778}, 118: {depth: 0, height: .43056, italic: .03588, skew: .02778}, 119: {depth: 0, height: .43056, italic: .02691, skew: .08334}, 120: {depth: 0, height: .43056, italic: 0, skew: .02778}, 121: {depth: .19444, height: .43056, italic: .03588, skew: .05556}, 122: {depth: 0, height: .43056, italic: .04398, skew: .05556}, 47: {depth: .19444, height: .69444, italic: 0, skew: 0}, 65: {depth: 0, height: .68333, italic: 0, skew: .13889}, 66: {depth: 0, height: .68333, italic: .05017, skew: .08334}, 67: {depth: 0, height: .68333, italic: .07153, skew: .08334}, 68: {depth: 0, height: .68333, italic: .02778, skew: .05556}, 69: {depth: 0, height: .68333, italic: .05764, skew: .08334}, 70: {depth: 0, height: .68333, italic: .13889, skew: .08334}, 71: {depth: 0, height: .68333, italic: 0, skew: .08334}, 72: {depth: 0, height: .68333, italic: .08125, skew: .05556}, 73: {depth: 0, height: .68333, italic: .07847, skew: .11111}, 74: {depth: 0, height: .68333, italic: .09618, skew: .16667}, 75: {depth: 0, height: .68333, italic: .07153, skew: .05556}, 76: {depth: 0, height: .68333, italic: 0, skew: .02778}, 77: {depth: 0, height: .68333, italic: .10903, skew: .08334}, 78: {depth: 0, height: .68333, italic: .10903, skew: .08334}, 79: {depth: 0, height: .68333, italic: .02778, skew: .08334}, 80: {depth: 0, height: .68333, italic: .13889, skew: .08334}, 81: {depth: .19444, height: .68333, italic: 0, skew: .08334}, 82: {depth: 0, height: .68333, italic: .00773, skew: .08334}, 83: {depth: 0, height: .68333, italic: .05764, skew: .08334}, 84: {depth: 0, height: .68333, italic: .13889, skew: .08334}, 85: {depth: 0, height: .68333, italic: .10903, skew: .02778}, 86: {depth: 0, height: .68333, italic: .22222, skew: 0}, 87: {depth: 0, height: .68333, italic: .13889, skew: 0}, 88: {depth: 0, height: .68333, italic: .07847, skew: .08334}, 89: {depth: 0, height: .68333, italic: .22222, skew: 0}, 90: {depth: 0, height: .68333, italic: .07153, skew: .08334}, 915: {depth: 0, height: .68333, italic: .13889, skew: .08334}, 916: {depth: 0, height: .68333, italic: 0, skew: .16667}, 920: {depth: 0, height: .68333, italic: .02778, skew: .08334}, 923: {depth: 0, height: .68333, italic: 0, skew: .16667}, 926: {depth: 0, height: .68333, italic: .07569, skew: .08334}, 928: {depth: 0, height: .68333, italic: .08125, skew: .05556}, 931: {depth: 0, height: .68333, italic: .05764, skew: .08334}, 933: {depth: 0, height: .68333, italic: .13889, skew: .05556}, 934: {depth: 0, height: .68333, italic: 0, skew: .08334}, 936: {depth: 0, height: .68333, italic: .11, skew: .05556}, 937: {depth: 0, height: .68333, italic: .05017, skew: .08334}, 945: {depth: 0, height: .43056, italic: .0037, skew: .02778}, 946: {depth: .19444, height: .69444, italic: .05278, skew: .08334}, 947: {depth: .19444, height: .43056, italic: .05556, skew: 0}, 948: {depth: 0, height: .69444, italic: .03785, skew: .05556}, 949: {depth: 0, height: .43056, italic: 0, skew: .08334}, 950: {depth: .19444, height: .69444, italic: .07378, skew: .08334}, 951: {depth: .19444, height: .43056, italic: .03588, skew: .05556}, 952: {depth: 0, height: .69444, italic: .02778, skew: .08334}, 953: {depth: 0, height: .43056, italic: 0, skew: .05556}, 954: {depth: 0, height: .43056, italic: 0, skew: 0}, 955: {depth: 0, height: .69444, italic: 0, skew: 0}, 956: {depth: .19444, height: .43056, italic: 0, skew: .02778}, 957: {depth: 0, height: .43056, italic: .06366, skew: .02778}, 958: {depth: .19444, height: .69444, italic: .04601, skew: .11111}, 959: {depth: 0, height: .43056, italic: 0, skew: .05556}, 960: {depth: 0, height: .43056, italic: .03588, skew: 0}, 961: {depth: .19444, height: .43056, italic: 0, skew: .08334}, 962: {depth: .09722, height: .43056, italic: .07986, skew: .08334}, 963: {depth: 0, height: .43056, italic: .03588, skew: 0}, 964: {depth: 0, height: .43056, italic: .1132, skew: .02778}, 965: {depth: 0, height: .43056, italic: .03588, skew: .02778}, 966: {depth: .19444, height: .43056, italic: 0, skew: .08334}, 967: {depth: .19444, height: .43056, italic: 0, skew: .05556}, 968: {depth: .19444, height: .69444, italic: .03588, skew: .11111}, 969: {depth: 0, height: .43056, italic: .03588, skew: 0}, 97: {depth: 0, height: .43056, italic: 0, skew: 0}, 977: {depth: 0, height: .69444, italic: 0, skew: .08334}, 98: {depth: 0, height: .69444, italic: 0, skew: 0}, 981: {depth: .19444, height: .69444, italic: 0, skew: .08334}, 982: {depth: 0, height: .43056, italic: .02778, skew: 0}, 99: {depth: 0, height: .43056, italic: 0, skew: .05556}}, "Math-Regular": {100: {depth: 0, height: .69444, italic: 0, skew: .16667}, 1009: {depth: .19444, height: .43056, italic: 0, skew: .08334}, 101: {depth: 0, height: .43056, italic: 0, skew: .05556}, 1013: {depth: 0, height: .43056, italic: 0, skew: .05556}, 102: {depth: .19444, height: .69444, italic: .10764, skew: .16667}, 103: {depth: .19444, height: .43056, italic: .03588, skew: .02778}, 104: {depth: 0, height: .69444, italic: 0, skew: 0}, 105: {depth: 0, height: .65952, italic: 0, skew: 0}, 106: {depth: .19444, height: .65952, italic: .05724, skew: 0}, 107: {depth: 0, height: .69444, italic: .03148, skew: 0}, 108: {depth: 0, height: .69444, italic: .01968, skew: .08334}, 109: {depth: 0, height: .43056, italic: 0, skew: 0}, 110: {depth: 0, height: .43056, italic: 0, skew: 0}, 111: {depth: 0, height: .43056, italic: 0, skew: .05556}, 112: {depth: .19444, height: .43056, italic: 0, skew: .08334}, 113: {depth: .19444, height: .43056, italic: .03588, skew: .08334}, 114: {depth: 0, height: .43056, italic: .02778, skew: .05556}, 115: {depth: 0, height: .43056, italic: 0, skew: .05556}, 116: {depth: 0, height: .61508, italic: 0, skew: .08334}, 117: {depth: 0, height: .43056, italic: 0, skew: .02778}, 118: {depth: 0, height: .43056, italic: .03588, skew: .02778}, 119: {depth: 0, height: .43056, italic: .02691, skew: .08334}, 120: {depth: 0, height: .43056, italic: 0, skew: .02778}, 121: {depth: .19444, height: .43056, italic: .03588, skew: .05556}, 122: {depth: 0, height: .43056, italic: .04398, skew: .05556}, 65: {depth: 0, height: .68333, italic: 0, skew: .13889}, 66: {depth: 0, height: .68333, italic: .05017, skew: .08334}, 67: {depth: 0, height: .68333, italic: .07153, skew: .08334}, 68: {depth: 0, height: .68333, italic: .02778, skew: .05556}, 69: {depth: 0, height: .68333, italic: .05764, skew: .08334}, 70: {depth: 0, height: .68333, italic: .13889, skew: .08334}, 71: {depth: 0, height: .68333, italic: 0, skew: .08334}, 72: {depth: 0, height: .68333, italic: .08125, skew: .05556}, 73: {depth: 0, height: .68333, italic: .07847, skew: .11111}, 74: {depth: 0, height: .68333, italic: .09618, skew: .16667}, 75: {depth: 0, height: .68333, italic: .07153, skew: .05556}, 76: {depth: 0, height: .68333, italic: 0, skew: .02778}, 77: {depth: 0, height: .68333, italic: .10903, skew: .08334}, 78: {depth: 0, height: .68333, italic: .10903, skew: .08334}, 79: {depth: 0, height: .68333, italic: .02778, skew: .08334}, 80: {depth: 0, height: .68333, italic: .13889, skew: .08334}, 81: {depth: .19444, height: .68333, italic: 0, skew: .08334}, 82: {depth: 0, height: .68333, italic: .00773, skew: .08334}, 83: {depth: 0, height: .68333, italic: .05764, skew: .08334}, 84: {depth: 0, height: .68333, italic: .13889, skew: .08334}, 85: {depth: 0, height: .68333, italic: .10903, skew: .02778}, 86: {depth: 0, height: .68333, italic: .22222, skew: 0}, 87: {depth: 0, height: .68333, italic: .13889, skew: 0}, 88: {depth: 0, height: .68333, italic: .07847, skew: .08334}, 89: {depth: 0, height: .68333, italic: .22222, skew: 0}, 90: {depth: 0, height: .68333, italic: .07153, skew: .08334}, 915: {depth: 0, height: .68333, italic: .13889, skew: .08334}, 916: {depth: 0, height: .68333, italic: 0, skew: .16667}, 920: {depth: 0, height: .68333, italic: .02778, skew: .08334}, 923: {depth: 0, height: .68333, italic: 0, skew: .16667}, 926: {depth: 0, height: .68333, italic: .07569, skew: .08334}, 928: {depth: 0, height: .68333, italic: .08125, skew: .05556}, 931: {depth: 0, height: .68333, italic: .05764, skew: .08334}, 933: {depth: 0, height: .68333, italic: .13889, skew: .05556}, 934: {depth: 0, height: .68333, italic: 0, skew: .08334}, 936: {depth: 0, height: .68333, italic: .11, skew: .05556}, 937: {depth: 0, height: .68333, italic: .05017, skew: .08334}, 945: {depth: 0, height: .43056, italic: .0037, skew: .02778}, 946: {depth: .19444, height: .69444, italic: .05278, skew: .08334}, 947: {depth: .19444, height: .43056, italic: .05556, skew: 0}, 948: {depth: 0, height: .69444, italic: .03785, skew: .05556}, 949: {depth: 0, height: .43056, italic: 0, skew: .08334}, 950: {depth: .19444, height: .69444, italic: .07378, skew: .08334}, 951: {depth: .19444, height: .43056, italic: .03588, skew: .05556}, 952: {depth: 0, height: .69444, italic: .02778, skew: .08334}, 953: {depth: 0, height: .43056, italic: 0, skew: .05556}, 954: {depth: 0, height: .43056, italic: 0, skew: 0}, 955: {depth: 0, height: .69444, italic: 0, skew: 0}, 956: {depth: .19444, height: .43056, italic: 0, skew: .02778}, 957: {depth: 0, height: .43056, italic: .06366, skew: .02778}, 958: {depth: .19444, height: .69444, italic: .04601, skew: .11111}, 959: {depth: 0, height: .43056, italic: 0, skew: .05556}, 960: {depth: 0, height: .43056, italic: .03588, skew: 0}, 961: {depth: .19444, height: .43056, italic: 0, skew: .08334}, 962: {depth: .09722, height: .43056, italic: .07986, skew: .08334}, 963: {depth: 0, height: .43056, italic: .03588, skew: 0}, 964: {depth: 0, height: .43056, italic: .1132, skew: .02778}, 965: {depth: 0, height: .43056, italic: .03588, skew: .02778}, 966: {depth: .19444, height: .43056, italic: 0, skew: .08334}, 967: {depth: .19444, height: .43056, italic: 0, skew: .05556}, 968: {depth: .19444, height: .69444, italic: .03588, skew: .11111}, 969: {depth: 0, height: .43056, italic: .03588, skew: 0}, 97: {depth: 0, height: .43056, italic: 0, skew: 0}, 977: {depth: 0, height: .69444, italic: 0, skew: .08334}, 98: {depth: 0, height: .69444, italic: 0, skew: 0}, 981: {depth: .19444, height: .69444, italic: 0, skew: .08334}, 982: {depth: 0, height: .43056, italic: .02778, skew: 0}, 99: {depth: 0, height: .43056, italic: 0, skew: .05556}}, "Size1-Regular": {8748: {depth: .306, height: .805, italic: .19445, skew: 0}, 8749: {depth: .306, height: .805, italic: .19445, skew: 0}, 10216: {depth: .35001, height: .85, italic: 0, skew: 0}, 10217: {depth: .35001, height: .85, italic: 0, skew: 0}, 10752: {depth: .25001, height: .75, italic: 0, skew: 0}, 10753: {depth: .25001, height: .75, italic: 0, skew: 0}, 10754: {depth: .25001, height: .75, italic: 0, skew: 0}, 10756: {depth: .25001, height: .75, italic: 0, skew: 0}, 10758: {depth: .25001, height: .75, italic: 0, skew: 0}, 123: {depth: .35001, height: .85, italic: 0, skew: 0}, 125: {depth: .35001, height: .85, italic: 0, skew: 0}, 40: {depth: .35001, height: .85, italic: 0, skew: 0}, 41: {depth: .35001, height: .85, italic: 0, skew: 0}, 47: {depth: .35001, height: .85, italic: 0, skew: 0}, 710: {depth: 0, height: .72222, italic: 0, skew: 0}, 732: {depth: 0, height: .72222, italic: 0, skew: 0}, 770: {depth: 0, height: .72222, italic: 0, skew: 0}, 771: {depth: 0, height: .72222, italic: 0, skew: 0}, 8214: {depth: -99e-5, height: .601, italic: 0, skew: 0}, 8593: {depth: 1e-5, height: .6, italic: 0, skew: 0}, 8595: {depth: 1e-5, height: .6, italic: 0, skew: 0}, 8657: {depth: 1e-5, height: .6, italic: 0, skew: 0}, 8659: {depth: 1e-5, height: .6, italic: 0, skew: 0}, 8719: {depth: .25001, height: .75, italic: 0, skew: 0}, 8720: {depth: .25001, height: .75, italic: 0, skew: 0}, 8721: {depth: .25001, height: .75, italic: 0, skew: 0}, 8730: {depth: .35001, height: .85, italic: 0, skew: 0}, 8739: {depth: -.00599, height: .606, italic: 0, skew: 0}, 8741: {depth: -.00599, height: .606, italic: 0, skew: 0}, 8747: {depth: .30612, height: .805, italic: .19445, skew: 0}, 8750: {depth: .30612, height: .805, italic: .19445, skew: 0}, 8896: {depth: .25001, height: .75, italic: 0, skew: 0}, 8897: {depth: .25001, height: .75, italic: 0, skew: 0}, 8898: {depth: .25001, height: .75, italic: 0, skew: 0}, 8899: {depth: .25001, height: .75, italic: 0, skew: 0}, 8968: {depth: .35001, height: .85, italic: 0, skew: 0}, 8969: {depth: .35001, height: .85, italic: 0, skew: 0}, 8970: {depth: .35001, height: .85, italic: 0, skew: 0}, 8971: {depth: .35001, height: .85, italic: 0, skew: 0}, 91: {depth: .35001, height: .85, italic: 0, skew: 0}, 9168: {depth: -99e-5, height: .601, italic: 0, skew: 0}, 92: {depth: .35001, height: .85, italic: 0, skew: 0}, 93: {depth: .35001, height: .85, italic: 0, skew: 0}}, "Size2-Regular": {8748: {depth: .862, height: 1.36, italic: .44445, skew: 0}, 8749: {depth: .862, height: 1.36, italic: .44445, skew: 0}, 10216: {depth: .65002, height: 1.15, italic: 0, skew: 0}, 10217: {depth: .65002, height: 1.15, italic: 0, skew: 0}, 10752: {depth: .55001, height: 1.05, italic: 0, skew: 0}, 10753: {depth: .55001, height: 1.05, italic: 0, skew: 0}, 10754: {depth: .55001, height: 1.05, italic: 0, skew: 0}, 10756: {depth: .55001, height: 1.05, italic: 0, skew: 0}, 10758: {depth: .55001, height: 1.05, italic: 0, skew: 0}, 123: {depth: .65002, height: 1.15, italic: 0, skew: 0}, 125: {depth: .65002, height: 1.15, italic: 0, skew: 0}, 40: {depth: .65002, height: 1.15, italic: 0, skew: 0}, 41: {depth: .65002, height: 1.15, italic: 0, skew: 0}, 47: {depth: .65002, height: 1.15, italic: 0, skew: 0}, 710: {depth: 0, height: .75, italic: 0, skew: 0}, 732: {depth: 0, height: .75, italic: 0, skew: 0}, 770: {depth: 0, height: .75, italic: 0, skew: 0}, 771: {depth: 0, height: .75, italic: 0, skew: 0}, 8719: {depth: .55001, height: 1.05, italic: 0, skew: 0}, 8720: {depth: .55001, height: 1.05, italic: 0, skew: 0}, 8721: {depth: .55001, height: 1.05, italic: 0, skew: 0}, 8730: {depth: .65002, height: 1.15, italic: 0, skew: 0}, 8747: {depth: .86225, height: 1.36, italic: .44445, skew: 0}, 8750: {depth: .86225, height: 1.36, italic: .44445, skew: 0}, 8896: {depth: .55001, height: 1.05, italic: 0, skew: 0}, 8897: {depth: .55001, height: 1.05, italic: 0, skew: 0}, 8898: {depth: .55001, height: 1.05, italic: 0, skew: 0}, 8899: {depth: .55001, height: 1.05, italic: 0, skew: 0}, 8968: {depth: .65002, height: 1.15, italic: 0, skew: 0}, 8969: {depth: .65002, height: 1.15, italic: 0, skew: 0}, 8970: {depth: .65002, height: 1.15, italic: 0, skew: 0}, 8971: {depth: .65002, height: 1.15, italic: 0, skew: 0}, 91: {depth: .65002, height: 1.15, italic: 0, skew: 0}, 92: {depth: .65002, height: 1.15, italic: 0, skew: 0}, 93: {depth: .65002, height: 1.15, italic: 0, skew: 0}}, "Size3-Regular": {10216: {depth: .95003, height: 1.45, italic: 0, skew: 0}, 10217: {depth: .95003, height: 1.45, italic: 0, skew: 0}, 123: {depth: .95003, height: 1.45, italic: 0, skew: 0}, 125: {depth: .95003, height: 1.45, italic: 0, skew: 0}, 40: {depth: .95003, height: 1.45, italic: 0, skew: 0}, 41: {depth: .95003, height: 1.45, italic: 0, skew: 0}, 47: {depth: .95003, height: 1.45, italic: 0, skew: 0}, 710: {depth: 0, height: .75, italic: 0, skew: 0}, 732: {depth: 0, height: .75, italic: 0, skew: 0}, 770: {depth: 0, height: .75, italic: 0, skew: 0}, 771: {depth: 0, height: .75, italic: 0, skew: 0}, 8730: {depth: .95003, height: 1.45, italic: 0, skew: 0}, 8968: {depth: .95003, height: 1.45, italic: 0, skew: 0}, 8969: {depth: .95003, height: 1.45, italic: 0, skew: 0}, 8970: {depth: .95003, height: 1.45, italic: 0, skew: 0}, 8971: {depth: .95003, height: 1.45, italic: 0, skew: 0}, 91: {depth: .95003, height: 1.45, italic: 0, skew: 0}, 92: {depth: .95003, height: 1.45, italic: 0, skew: 0}, 93: {depth: .95003, height: 1.45, italic: 0, skew: 0}}, "Size4-Regular": {10216: {depth: 1.25003, height: 1.75, italic: 0, skew: 0}, 10217: {depth: 1.25003, height: 1.75, italic: 0, skew: 0}, 123: {depth: 1.25003, height: 1.75, italic: 0, skew: 0}, 125: {depth: 1.25003, height: 1.75, italic: 0, skew: 0}, 40: {depth: 1.25003, height: 1.75, italic: 0, skew: 0}, 41: {depth: 1.25003, height: 1.75, italic: 0, skew: 0}, 47: {depth: 1.25003, height: 1.75, italic: 0, skew: 0}, 57344: {depth: -.00499, height: .605, italic: 0, skew: 0}, 57345: {depth: -.00499, height: .605, italic: 0, skew: 0}, 57680: {depth: 0, height: .12, italic: 0, skew: 0}, 57681: {depth: 0, height: .12, italic: 0, skew: 0}, 57682: {depth: 0, height: .12, italic: 0, skew: 0}, 57683: {depth: 0, height: .12, italic: 0, skew: 0}, 710: {depth: 0, height: .825, italic: 0, skew: 0}, 732: {depth: 0, height: .825, italic: 0, skew: 0}, 770: {depth: 0, height: .825, italic: 0, skew: 0}, 771: {depth: 0, height: .825, italic: 0, skew: 0}, 8730: {depth: 1.25003, height: 1.75, italic: 0, skew: 0}, 8968: {depth: 1.25003, height: 1.75, italic: 0, skew: 0}, 8969: {depth: 1.25003, height: 1.75, italic: 0, skew: 0}, 8970: {depth: 1.25003, height: 1.75, italic: 0, skew: 0}, 8971: {depth: 1.25003, height: 1.75, italic: 0, skew: 0}, 91: {depth: 1.25003, height: 1.75, italic: 0, skew: 0}, 9115: {depth: .64502, height: 1.155, italic: 0, skew: 0}, 9116: {depth: 1e-5, height: .6, italic: 0, skew: 0}, 9117: {depth: .64502, height: 1.155, italic: 0, skew: 0}, 9118: {depth: .64502, height: 1.155, italic: 0, skew: 0}, 9119: {depth: 1e-5, height: .6, italic: 0, skew: 0}, 9120: {depth: .64502, height: 1.155, italic: 0, skew: 0}, 9121: {depth: .64502, height: 1.155, italic: 0, skew: 0}, 9122: {depth: -99e-5, height: .601, italic: 0, skew: 0}, 9123: {depth: .64502, height: 1.155, italic: 0, skew: 0}, 9124: {depth: .64502, height: 1.155, italic: 0, skew: 0}, 9125: {depth: -99e-5, height: .601, italic: 0, skew: 0}, 9126: {depth: .64502, height: 1.155, italic: 0, skew: 0}, 9127: {depth: 1e-5, height: .9, italic: 0, skew: 0}, 9128: {depth: .65002, height: 1.15, italic: 0, skew: 0}, 9129: {depth: .90001, height: 0, italic: 0, skew: 0}, 9130: {depth: 0, height: .3, italic: 0, skew: 0}, 9131: {depth: 1e-5, height: .9, italic: 0, skew: 0}, 9132: {depth: .65002, height: 1.15, italic: 0, skew: 0}, 9133: {depth: .90001, height: 0, italic: 0, skew: 0}, 9143: {depth: .88502, height: .915, italic: 0, skew: 0}, 92: {depth: 1.25003, height: 1.75, italic: 0, skew: 0}, 93: {depth: 1.25003, height: 1.75, italic: 0, skew: 0}}};
                var V = function (e, t) {
                    return H[t][e.charCodeAt(0)]
                };
                t.exports = {metrics: X, getCharacterMetrics: V}
            }, {"./Style": 6}], 12: [function (e, t, i) {
                var h = e("./utils");
                var a = e("./ParseError");
                var l = {"\\sqrt": {numArgs: 1, numOptionalArgs: 1, handler: function (e, t, i, h) {
                            if (t != null) {
                                throw new a("Optional arguments to \\sqrt aren't supported yet", this.lexer, h[1] - 1)
                            }
                            return{type: "sqrt", body: i}
                        }}, "\\text": {numArgs: 1, argTypes: ["text"], greediness: 2, handler: function (e, t) {
                            var i;
                            if (t.type === "ordgroup") {
                                i = t.value
                            } else {
                                i = [t]
                            }
                            return{type: "text", body: i}
                        }}, "\\color": {numArgs: 2, allowedInText: true, argTypes: ["color", "original"], handler: function (e, t, i) {
                            var h;
                            if (i.type === "ordgroup") {
                                h = i.value
                            } else {
                                h = [i]
                            }
                            return{type: "color", color: t.value, value: h}
                        }}, "\\overline": {numArgs: 1, handler: function (e, t) {
                            return{type: "overline", body: t}
                        }}, "\\rule": {numArgs: 2, numOptionalArgs: 1, argTypes: ["size", "size", "size"], handler: function (e, t, i, h) {
                            return{type: "rule", shift: t && t.value, width: i.value, height: h.value}
                        }}, "\\KaTeX": {numArgs: 0, handler: function (e) {
                            return{type: "katex"}
                        }}};
                var s = {"\\bigl": {type: "open", size: 1}, "\\Bigl": {type: "open", size: 2}, "\\biggl": {type: "open", size: 3}, "\\Biggl": {type: "open", size: 4}, "\\bigr": {type: "close", size: 1}, "\\Bigr": {type: "close", size: 2}, "\\biggr": {type: "close", size: 3}, "\\Biggr": {type: "close", size: 4}, "\\bigm": {type: "rel", size: 1}, "\\Bigm": {type: "rel", size: 2}, "\\biggm": {type: "rel", size: 3}, "\\Biggm": {type: "rel", size: 4}, "\\big": {type: "textord", size: 1}, "\\Big": {type: "textord", size: 2}, "\\bigg": {type: "textord", size: 3}, "\\Bigg": {type: "textord", size: 4}};
                var r = ["(", ")", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "\\lceil", "\\rceil", "<", ">", "\\langle", "\\rangle", "/", "\\backslash", "|", "\\vert", "\\|", "\\Vert", "\\uparrow", "\\Uparrow", "\\downarrow", "\\Downarrow", "\\updownarrow", "\\Updownarrow", "."];
                var p = [{funcs: ["\\blue", "\\orange", "\\pink", "\\red", "\\green", "\\gray", "\\purple"], data: {numArgs: 1, allowedInText: true, handler: function (e, t) {
                                var i;
                                if (t.type === "ordgroup") {
                                    i = t.value
                                } else {
                                    i = [t]
                                }
                                return{type: "color", color: "katex-" + e.slice(1), value: i}
                            }}}, {funcs: ["\\arcsin", "\\arccos", "\\arctan", "\\arg", "\\cos", "\\cosh", "\\cot", "\\coth", "\\csc", "\\deg", "\\dim", "\\exp", "\\hom", "\\ker", "\\lg", "\\ln", "\\log", "\\sec", "\\sin", "\\sinh", "\\tan", "\\tanh"], data: {numArgs: 0, handler: function (e) {
                                return{type: "op", limits: false, symbol: false, body: e}
                            }}}, {funcs: ["\\det", "\\gcd", "\\inf", "\\lim", "\\liminf", "\\limsup", "\\max", "\\min", "\\Pr", "\\sup"], data: {numArgs: 0, handler: function (e) {
                                return{type: "op", limits: true, symbol: false, body: e}
                            }}}, {funcs: ["\\int", "\\iint", "\\iiint", "\\oint"], data: {numArgs: 0, handler: function (e) {
                                return{type: "op", limits: false, symbol: true, body: e}
                            }}}, {funcs: ["\\coprod", "\\bigvee", "\\bigwedge", "\\biguplus", "\\bigcap", "\\bigcup", "\\intop", "\\prod", "\\sum", "\\bigotimes", "\\bigoplus", "\\bigodot", "\\bigsqcup", "\\smallint"], data: {numArgs: 0, handler: function (e) {
                                return{type: "op", limits: true, symbol: true, body: e}
                            }}}, {funcs: ["\\dfrac", "\\frac", "\\tfrac", "\\dbinom", "\\binom", "\\tbinom"], data: {numArgs: 2, greediness: 2, handler: function (e, t, i) {
                                var h;
                                var a = null;
                                var l = null;
                                var s = "auto";
                                switch (e) {
                                    case"\\dfrac":
                                    case"\\frac":
                                    case"\\tfrac":
                                        h = true;
                                        break;
                                    case"\\dbinom":
                                    case"\\binom":
                                    case"\\tbinom":
                                        h = false;
                                        a = "(";
                                        l = ")";
                                        break;
                                    default:
                                        throw new Error("Unrecognized genfrac command")
                                }
                                switch (e) {
                                    case"\\dfrac":
                                    case"\\dbinom":
                                        s = "display";
                                        break;
                                    case"\\tfrac":
                                    case"\\tbinom":
                                        s = "text";
                                        break
                                }
                                return{type: "genfrac", numer: t, denom: i, hasBarLine: h, leftDelim: a, rightDelim: l, size: s}
                            }}}, {funcs: ["\\llap", "\\rlap"], data: {numArgs: 1, allowedInText: true, handler: function (e, t) {
                                return{type: e.slice(1), body: t}
                            }}}, {funcs: ["\\bigl", "\\Bigl", "\\biggl", "\\Biggl", "\\bigr", "\\Bigr", "\\biggr", "\\Biggr", "\\bigm", "\\Bigm", "\\biggm", "\\Biggm", "\\big", "\\Big", "\\bigg", "\\Bigg", "\\left", "\\right"], data: {numArgs: 1, handler: function (e, t, i) {
                                if (!h.contains(r, t.value)) {
                                    throw new a("Invalid delimiter: '" + t.value + "' after '" + e + "'", this.lexer, i[1])
                                }
                                if (e === "\\left" || e === "\\right") {
                                    return{type: "leftright", value: t.value}
                                } else {
                                    return{type: "delimsizing", size: s[e].size, delimType: s[e].type, value: t.value}
                                }
                            }}}, {funcs: ["\\tiny", "\\scriptsize", "\\footnotesize", "\\small", "\\normalsize", "\\large", "\\Large", "\\LARGE", "\\huge", "\\Huge"], data: {numArgs: 0}}, {funcs: ["\\displaystyle", "\\textstyle", "\\scriptstyle", "\\scriptscriptstyle"], data: {numArgs: 0}}, {funcs: ["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot"], data: {numArgs: 1, handler: function (e, t) {
                                return{type: "accent", accent: e, base: t}
                            }}}, {funcs: ["\\over", "\\choose"], data: {numArgs: 0, handler: function (e) {
                                var t;
                                switch (e) {
                                    case"\\over":
                                        t = "\\frac";
                                        break;
                                    case"\\choose":
                                        t = "\\binom";
                                        break;
                                    default:
                                        throw new Error("Unrecognized infix genfrac command")
                                }
                                return{type: "infix", replaceWith: t}
                            }}}];
                var c = function (e, t) {
                    for (var i = 0; i < e.length; i++) {
                        l[e[i]] = t
                    }
                };
                for (var g = 0; g < p.length; g++) {
                    c(p[g].funcs, p[g].data)
                }
                var d = function (e) {
                    if (l[e].greediness === undefined) {
                        return 1
                    } else {
                        return l[e].greediness
                    }
                };
                for (var n in l) {
                    if (l.hasOwnProperty(n)) {
                        var o = l[n];
                        l[n] = {numArgs: o.numArgs, argTypes: o.argTypes, greediness: o.greediness === undefined ? 1 : o.greediness, allowedInText: o.allowedInText ? o.allowedInText : false, numOptionalArgs: o.numOptionalArgs === undefined ? 0 : o.numOptionalArgs, handler: o.handler}
                    }
                }
                t.exports = {funcs: l, getGreediness: d}
            }, {"./ParseError": 4, "./utils": 15}], 13: [function (e, t, i) {
                var h = e("./Parser");
                var a = function (e) {
                    var t = new h(e);
                    return t.parse()
                };
                t.exports = a
            }, {"./Parser": 5}], 14: [function (e, t, i) {
                var h = {math: {"`": {font: "main", group: "textord", replace: "\u2018"}, "\\$": {font: "main", group: "textord", replace: "$"}, "\\%": {font: "main", group: "textord", replace: "%"}, "\\_": {font: "main", group: "textord", replace: "_"}, "\\angle": {font: "main", group: "textord", replace: "\u2220"}, "\\infty": {font: "main", group: "textord", replace: "\u221e"}, "\\prime": {font: "main", group: "textord", replace: "\u2032"}, "\\triangle": {font: "main", group: "textord", replace: "\u25b3"}, "\\Gamma": {font: "main", group: "textord", replace: "\u0393"}, "\\Delta": {font: "main", group: "textord", replace: "\u0394"}, "\\Theta": {font: "main", group: "textord", replace: "\u0398"}, "\\Lambda": {font: "main", group: "textord", replace: "\u039b"}, "\\Xi": {font: "main", group: "textord", replace: "\u039e"}, "\\Pi": {font: "main", group: "textord", replace: "\u03a0"}, "\\Sigma": {font: "main", group: "textord", replace: "\u03a3"}, "\\Upsilon": {font: "main", group: "textord", replace: "\u03a5"}, "\\Phi": {font: "main", group: "textord", replace: "\u03a6"}, "\\Psi": {font: "main", group: "textord", replace: "\u03a8"}, "\\Omega": {font: "main", group: "textord", replace: "\u03a9"}, "\\neg": {font: "main", group: "textord", replace: "\xac"}, "\\lnot": {font: "main", group: "textord", replace: "\xac"}, "\\top": {font: "main", group: "textord", replace: "\u22a4"}, "\\bot": {font: "main", group: "textord", replace: "\u22a5"}, "\\emptyset": {font: "main", group: "textord", replace: "\u2205"}, "\\varnothing": {font: "ams", group: "textord", replace: "\u2205"}, "\\alpha": {font: "main", group: "mathord", replace: "\u03b1"}, "\\beta": {font: "main", group: "mathord", replace: "\u03b2"}, "\\gamma": {font: "main", group: "mathord", replace: "\u03b3"}, "\\delta": {font: "main", group: "mathord", replace: "\u03b4"}, "\\epsilon": {font: "main", group: "mathord", replace: "\u03f5"}, "\\zeta": {font: "main", group: "mathord", replace: "\u03b6"}, "\\eta": {font: "main", group: "mathord", replace: "\u03b7"}, "\\theta": {font: "main", group: "mathord", replace: "\u03b8"}, "\\iota": {font: "main", group: "mathord", replace: "\u03b9"}, "\\kappa": {font: "main", group: "mathord", replace: "\u03ba"}, "\\lambda": {font: "main", group: "mathord", replace: "\u03bb"}, "\\mu": {font: "main", group: "mathord", replace: "\u03bc"}, "\\nu": {font: "main", group: "mathord", replace: "\u03bd"}, "\\xi": {font: "main", group: "mathord", replace: "\u03be"}, "\\omicron": {font: "main", group: "mathord", replace: "o"}, "\\pi": {font: "main", group: "mathord", replace: "\u03c0"}, "\\rho": {font: "main", group: "mathord", replace: "\u03c1"}, "\\sigma": {font: "main", group: "mathord", replace: "\u03c3"}, "\\tau": {font: "main", group: "mathord", replace: "\u03c4"}, "\\upsilon": {font: "main", group: "mathord", replace: "\u03c5"}, "\\phi": {font: "main", group: "mathord", replace: "\u03d5"}, "\\chi": {font: "main", group: "mathord", replace: "\u03c7"}, "\\psi": {font: "main", group: "mathord", replace: "\u03c8"}, "\\omega": {font: "main", group: "mathord", replace: "\u03c9"}, "\\varepsilon": {font: "main", group: "mathord", replace: "\u03b5"}, "\\vartheta": {font: "main", group: "mathord", replace: "\u03d1"}, "\\varpi": {font: "main", group: "mathord", replace: "\u03d6"}, "\\varrho": {font: "main", group: "mathord", replace: "\u03f1"}, "\\varsigma": {font: "main", group: "mathord", replace: "\u03c2"}, "\\varphi": {font: "main", group: "mathord", replace: "\u03c6"}, "*": {font: "main", group: "bin", replace: "\u2217"}, "+": {font: "main", group: "bin"}, "-": {font: "main", group: "bin", replace: "\u2212"}, "\\cdot": {font: "main", group: "bin", replace: "\u22c5"}, "\\circ": {font: "main", group: "bin", replace: "\u2218"}, "\\div": {font: "main", group: "bin", replace: "\xf7"}, "\\pm": {font: "main", group: "bin", replace: "\xb1"}, "\\times": {font: "main", group: "bin", replace: "\xd7"}, "\\cap": {font: "main", group: "bin", replace: "\u2229"}, "\\cup": {font: "main", group: "bin", replace: "\u222a"}, "\\setminus": {font: "main", group: "bin", replace: "\u2216"}, "\\land": {font: "main", group: "bin", replace: "\u2227"}, "\\lor": {font: "main", group: "bin", replace: "\u2228"}, "\\wedge": {font: "main", group: "bin", replace: "\u2227"}, "\\vee": {font: "main", group: "bin", replace: "\u2228"}, "\\surd": {font: "main", group: "textord", replace: "\u221a"}, "(": {font: "main", group: "open"}, "[": {font: "main", group: "open"}, "\\langle": {font: "main", group: "open", replace: "\u27e8"}, "\\lvert": {font: "main", group: "open", replace: "\u2223"}, ")": {font: "main", group: "close"}, "]": {font: "main", group: "close"}, "?": {font: "main", group: "close"}, "!": {font: "main", group: "close"}, "\\rangle": {font: "main", group: "close", replace: "\u27e9"}, "\\rvert": {font: "main", group: "close", replace: "\u2223"}, "=": {font: "main", group: "rel"}, "<": {font: "main", group: "rel"}, ">": {font: "main", group: "rel"}, ":": {font: "main", group: "rel"}, "\\approx": {font: "main", group: "rel", replace: "\u2248"}, "\\cong": {font: "main", group: "rel", replace: "\u2245"}, "\\ge": {font: "main", group: "rel", replace: "\u2265"}, "\\geq": {font: "main", group: "rel", replace: "\u2265"}, "\\gets": {font: "main", group: "rel", replace: "\u2190"}, "\\in": {font: "main", group: "rel", replace: "\u2208"}, "\\notin": {font: "main", group: "rel", replace: "\u2209"}, "\\subset": {font: "main", group: "rel", replace: "\u2282"}, "\\supset": {font: "main", group: "rel", replace: "\u2283"}, "\\subseteq": {font: "main", group: "rel", replace: "\u2286"}, "\\supseteq": {font: "main", group: "rel", replace: "\u2287"}, "\\nsubseteq": {font: "ams", group: "rel", replace: "\u2288"}, "\\nsupseteq": {font: "ams", group: "rel", replace: "\u2289"}, "\\models": {font: "main", group: "rel", replace: "\u22a8"}, "\\leftarrow": {font: "main", group: "rel", replace: "\u2190"}, "\\le": {font: "main", group: "rel", replace: "\u2264"}, "\\leq": {font: "main", group: "rel", replace: "\u2264"}, "\\ne": {font: "main", group: "rel", replace: "\u2260"}, "\\neq": {font: "main", group: "rel", replace: "\u2260"}, "\\rightarrow": {font: "main", group: "rel", replace: "\u2192"}, "\\to": {font: "main", group: "rel", replace: "\u2192"}, "\\ngeq": {font: "ams", group: "rel", replace: "\u2271"}, "\\nleq": {font: "ams", group: "rel", replace: "\u2270"}, "\\!": {font: "main", group: "spacing"}, "\\ ": {font: "main", group: "spacing", replace: "\xa0"}, "~": {font: "main", group: "spacing", replace: "\xa0"}, "\\,": {font: "main", group: "spacing"}, "\\:": {font: "main", group: "spacing"}, "\\;": {font: "main", group: "spacing"}, "\\enspace": {font: "main", group: "spacing"}, "\\qquad": {font: "main", group: "spacing"}, "\\quad": {font: "main", group: "spacing"}, "\\space": {font: "main", group: "spacing", replace: "\xa0"}, ",": {font: "main", group: "punct"}, ";": {font: "main", group: "punct"}, "\\colon": {font: "main", group: "punct", replace: ":"}, "\\barwedge": {font: "ams", group: "textord", replace: "\u22bc"}, "\\veebar": {font: "ams", group: "textord", replace: "\u22bb"}, "\\odot": {font: "main", group: "textord", replace: "\u2299"}, "\\oplus": {font: "main", group: "textord", replace: "\u2295"}, "\\otimes": {font: "main", group: "textord", replace: "\u2297"}, "\\partial": {font: "main", group: "textord", replace: "\u2202"}, "\\oslash": {font: "main", group: "textord", replace: "\u2298"}, "\\circledcirc": {font: "ams", group: "textord", replace: "\u229a"}, "\\boxdot": {font: "ams", group: "textord", replace: "\u22a1"}, "\\bigtriangleup": {font: "main", group: "textord", replace: "\u25b3"}, "\\bigtriangledown": {font: "main", group: "textord", replace: "\u25bd"}, "\\dagger": {font: "main", group: "textord", replace: "\u2020"}, "\\diamond": {font: "main", group: "textord", replace: "\u22c4"}, "\\star": {font: "main", group: "textord", replace: "\u22c6"}, "\\triangleleft": {font: "main", group: "textord", replace: "\u25c3"}, "\\triangleright": {font: "main", group: "textord", replace: "\u25b9"}, "\\{": {font: "main", group: "open", replace: "{"}, "\\}": {font: "main", group: "close", replace: "}"}, "\\lbrace": {font: "main", group: "open", replace: "{"}, "\\rbrace": {font: "main", group: "close", replace: "}"}, "\\lbrack": {font: "main", group: "open", replace: "["}, "\\rbrack": {font: "main", group: "close", replace: "]"}, "\\lfloor": {font: "main", group: "open", replace: "\u230a"}, "\\rfloor": {font: "main", group: "close", replace: "\u230b"}, "\\lceil": {font: "main", group: "open", replace: "\u2308"}, "\\rceil": {font: "main", group: "close", replace: "\u2309"}, "\\backslash": {font: "main", group: "textord", replace: "\\"}, "|": {font: "main", group: "textord", replace: "\u2223"}, "\\vert": {font: "main", group: "textord", replace: "\u2223"}, "\\|": {font: "main", group: "textord", replace: "\u2225"}, "\\Vert": {font: "main", group: "textord", replace: "\u2225"}, "\\uparrow": {font: "main", group: "textord", replace: "\u2191"}, "\\Uparrow": {font: "main", group: "textord", replace: "\u21d1"}, "\\downarrow": {font: "main", group: "textord", replace: "\u2193"}, "\\Downarrow": {font: "main", group: "textord", replace: "\u21d3"}, "\\updownarrow": {font: "main", group: "textord", replace: "\u2195"}, "\\Updownarrow": {font: "main", group: "textord", replace: "\u21d5"}, "\\coprod": {font: "math", group: "op", replace: "\u2210"}, "\\bigvee": {font: "math", group: "op", replace: "\u22c1"}, "\\bigwedge": {font: "math", group: "op", replace: "\u22c0"}, "\\biguplus": {font: "math", group: "op", replace: "\u2a04"}, "\\bigcap": {font: "math", group: "op", replace: "\u22c2"}, "\\bigcup": {font: "math", group: "op", replace: "\u22c3"}, "\\int": {font: "math", group: "op", replace: "\u222b"}, "\\intop": {font: "math", group: "op", replace: "\u222b"}, "\\iint": {font: "math", group: "op", replace: "\u222c"}, "\\iiint": {font: "math", group: "op", replace: "\u222d"}, "\\prod": {font: "math", group: "op", replace: "\u220f"}, "\\sum": {font: "math", group: "op", replace: "\u2211"}, "\\bigotimes": {font: "math", group: "op", replace: "\u2a02"}, "\\bigoplus": {font: "math", group: "op", replace: "\u2a01"}, "\\bigodot": {font: "math", group: "op", replace: "\u2a00"}, "\\oint": {font: "math", group: "op", replace: "\u222e"}, "\\bigsqcup": {font: "math", group: "op", replace: "\u2a06"}, "\\smallint": {font: "math", group: "op", replace: "\u222b"}, "\\ldots": {font: "main", group: "punct", replace: "\u2026"}, "\\cdots": {font: "main", group: "inner", replace: "\u22ef"}, "\\ddots": {font: "main", group: "inner", replace: "\u22f1"}, "\\vdots": {font: "main", group: "textord", replace: "\u22ee"}, "\\acute": {font: "main", group: "accent", replace: "\xb4"}, "\\grave": {font: "main", group: "accent", replace: "`"}, "\\ddot": {font: "main", group: "accent", replace: "\xa8"}, "\\tilde": {font: "main", group: "accent", replace: "~"}, "\\bar": {font: "main", group: "accent", replace: "\xaf"}, "\\breve": {font: "main", group: "accent", replace: "\u02d8"}, "\\check": {font: "main", group: "accent", replace: "\u02c7"}, "\\hat": {font: "main", group: "accent", replace: "^"}, "\\vec": {font: "main", group: "accent", replace: "\u20d7"}, "\\dot": {font: "main", group: "accent", replace: "\u02d9"}}, text: {"\\ ": {font: "main", group: "spacing", replace: "\xa0"}, " ": {font: "main", group: "spacing", replace: "\xa0"}, "~": {font: "main", group: "spacing", replace: "\xa0"}}};
                var a = '0123456789/@."';
                for (var l = 0; l < a.length; l++) {
                    var s = a.charAt(l);
                    h.math[s] = {font: "main", group: "textord"}
                }
                var r = "0123456789`!@*()-=+[]'\";:?/.,";
                for (var l = 0; l < r.length; l++) {
                    var s = r.charAt(l);
                    h.text[s] = {font: "main", group: "textord"}
                }
                var p = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
                for (var l = 0; l < p.length; l++) {
                    var s = p.charAt(l);
                    h.math[s] = {font: "main", group: "mathord"};
                    h.text[s] = {font: "main", group: "textord"}
                }
                t.exports = h
            }, {}], 15: [function (e, t, i) {
                var h = Array.prototype.indexOf;
                var a = function (e, t) {
                    if (e == null) {
                        return-1
                    }
                    if (h && e.indexOf === h) {
                        return e.indexOf(t)
                    }
                    var i = 0, a = e.length;
                    for (; i < a; i++) {
                        if (e[i] === t) {
                            return i
                        }
                    }
                    return-1
                };
                var l = function (e, t) {
                    return a(e, t) !== -1
                };
                var s = /([A-Z])/g;
                var r = function (e) {
                    return e.replace(s, "-$1").toLowerCase()
                };
                var p = {"&": "&amp;", ">": "&gt;", "<": "&lt;", '"': "&quot;", "'": "&#x27;"};
                var c = /[&><"']/g;
                function g(e) {
                    return p[e]
                }
                function d(e) {
                    return("" + e).replace(c, g)
                }
                var n;
                if (typeof document !== "undefined") {
                    var o = document.createElement("span");
                    if ("textContent"in o) {
                        n = function (e, t) {
                            e.textContent = t
                        }
                    } else {
                        n = function (e, t) {
                            e.innerText = t
                        }
                    }
                }
                function w(e) {
                    n(e, "")
                }
                t.exports = {contains: l, escape: d, hyphenate: r, indexOf: a, setTextContent: n, clearNode: w}
            }, {}]}, {}, [1])(1)
});